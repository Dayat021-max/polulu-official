<?php
 
namespace App\Controllers;

use App\Models\KategoriModels; 
use App\Models\ItemModels;
use CodeIgniter\Exceptions\PageNotFoundException;

class Landpage extends BaseController
{ 
    protected $KategoriModels;
    protected $ItemModels;

    public function __construct()
    {
        $this->KategoriModels       = new KategoriModels();
        $this->ItemModels           = new ItemModels();
    }

    public function index()   
    { 

        $kategori       = $this->KategoriModels->findAll();
        
        $data = [
            'title'     => '',
            'sub'       => 'Kategori Produk Database ',
            'kategori'  => $kategori
        ];

        echo view('tempt_us/header', $data);
        echo view('temp/topbar'); 
        echo view('home_page');
        echo view("tempt_us/footer");
    }

    public function list($id)
    {
        $KategoriModels = new KategoriModels();
        $ItemModels = new ItemModels();
        
        // Mendapatkan data kategori berdasarkan ID
        $item           = $this->ItemModels->findAll();
        $kategori = $KategoriModels->find($id);
        if (!$kategori) {
            throw PageNotFoundException::forPageNotFound();
        }
        
        // Mendapatkan item berdasarkan category_id
        $items = $ItemModels->where('id_kategori', $id)->findAll();

        // Menyiapkan data untuk dikirim ke view
        $data = [
            'title'     => 'List Produk',
            'kategori'  => $kategori,
            'items'     => $items,
            'item'      => $item
        ];

        echo view('tempt_us/header', $data);
        echo view('home/deskripsi', $data);
        echo view('tempt_us/footer');
    }

    public function view($id)
    {
        $KategoriModels = new KategoriModels();
        $ItemModels = new ItemModels();
        
        // Mendapatkan data kategori berdasarkan ID
        $item = $ItemModels->find($id);
        if (!$item) {
            throw PageNotFoundException::forPageNotFound();
        }
        
        // Mendapatkan item berdasarkan category_id
        $items = $ItemModels->where('id', $id)->findAll();

        // Menyiapkan data untuk dikirim ke view
        $data = [
            'title'     => 'List Produk',
            // 'kategori'  => $kategori,
            'items'     => $items,
            'item'      => $item
        ];

        echo view('tempt_us/header', $data);
        echo view('home/view', $data);
        echo view('tempt_us/footer');
    }
}
 
 