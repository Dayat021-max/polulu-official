<?php
 
namespace App\Controllers;

class Aksesoris extends BaseController
{ 
    public function index()  
    {  
        $data = [
            'title'     => '- Aksesoris', 
            'judul'     => 'Produk Aksesoris dan Peralatan Pendukung'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Aksesoris');
        echo view("tempt_us/footer");
    }

    public function baskom() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Baskom Lipat'
        ];

        echo view('tempt_us/header', $data);
        echo view('aksesoris/baskom');
        echo view("tempt_us/footer");
    }

    public function nail_care_set_duck() 
    {  
        $data = [
            'title'     => '- Aksesoris ',
            'judul'     => 'Nail Care Set Duck'
        ];

        echo view('tempt_us/header', $data);
        echo view('aksesoris/nail');
        echo view("tempt_us/footer");
    }

    public function Pegangan_Sendok_Kelinci() 
    {  
        $data = [
            'title'     => '- Aksesoris ',
            'judul'     => 'Pegangan Sendok Kelinci'
        ];

        echo view('tempt_us/header', $data);
        echo view('aksesoris/sendok_kelinci');
        echo view("tempt_us/footer");
    }

    public function Pegangan_Sendok() 
    {  
        $data = [
            'title'     => '- Aksesoris ',
            'judul'     => 'Pegangan Sendok'
        ];

        echo view('tempt_us/header', $data);
        echo view('aksesoris/pegangan_sendok');
        echo view("tempt_us/footer");
    }

    public function MPASI_PP() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal MPASI Dua Gagang'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/pp');
        echo view("tempt_us/footer");
    }

    public function paus() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal Paus'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/paus');
        echo view("tempt_us/footer");
    }

    public function gelas_takar() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Takar'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/takar');
        echo view("tempt_us/footer");
    }

    public function gelas_karakter() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Karakter'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/mug_karakter');
        echo view("tempt_us/footer");
    }

    public function gelas_karakter_polulu() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Karakter Polulu'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/mug_polulu');
        echo view("tempt_us/footer");
    }
}
  
