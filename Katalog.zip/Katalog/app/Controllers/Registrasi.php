<?php
  
namespace App\Controllers; 

use App\Models\UserModels; 
use App\Models\RoleModels;
use App\Models\StatusModels;


class Registrasi extends BaseController 
{ 
    protected $UserModels;
    protected $RoleModels;
    protected $StatusModels;

    public function __construct()
    {
        $this->UserModels   = new UserModels();
        $this->RoleModels   = new RoleModels();
        $this->StatusModels = new StatusModels();
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor
    }
   
    public function index() 
    {  
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        } 
        $userModel  = new UserModels();
        $roleModel  = new RoleModels();
        $username   = session()->get('username');
        $akses      = session()->get('role_id');
        
        // Mengambil data pengguna
        $user = $userModel->where('username', $username)->first();
        $role_id = $roleModel->find($user['role_id']);

        $rol_id        = $this->RoleModels->findAll();
        $user_account   = $this->UserModels->findAll();

        // Buat array asosiatif untuk memetakan role_id ke role_name
        $roleMap = [];
        foreach ($rol_id as $role)
        {
            $roleMap[$role['id']] = $role['role_id'];
        }

        // Tambahkan role_name ke setiap user
        foreach ($user_account as &$user)
        {
            $user['role_name'] = isset($roleMap[$user['role_id']]) ? $roleMap[$user['role_id']] : 'Unknown';
        }

        // Menggunakan getResultArray untuk mendapatkan hasil dalam bentuk array
        $data = [
            'title'         => '- Registrasi',
            'judul'         => 'Registrasi',
            'rol_id'       => $rol_id,
            'role_id'       => $role_id,
            'user_account'  => $user_account,
            'user'          => $user,
            'akses'         => $akses
        ];

        if($akses == 1)
        {
            echo view('tempt_us/header', $data);
            echo view('tempt_us/topbar');
            echo view('tempt_us/sidebar',$data);
            echo view('registrasi', $data);
            echo view("tempt_us/footer");
        } else {
             return redirect()->to('/restricted')->with('error', 'Anda tidak berhak mengakses halaman ini');
        }
        
    } 

    public function save()
{
    if (!$this->validate([
        'name' => [
            'rules' => 'required|trim|max_length[20]',
            'errors' => [
                'required'  => 'Nama wajib diisi.',
                'max_length'=> ' Tidak boleh terlalu panjang.'
            ],
        ],
        'username' => [
            'rules' => 'required|trim|is_unique[user.username]|max_length[20]',
            'errors' => [
                'required' => 'Username wajib diisi.',
                'is_unique' => 'Username sudah ada.',
                'max_length' => 'Username maksimal 20 karakter.'
            ], 
        ],
        'role_id' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Job Position wajib diisi.',
            ],
        ],
        'pp' => [ 
            'rules' => 'max_size[pp,2048]|is_image[pp]|mime_in[pp,image/jpg,image/jpeg,image/png]',
            'errors' => [
                'max_size' => 'Ukuran gambar terlalu besar.',
                'is_image' => 'File harus berupa gambar.',
                'mime_in'  => 'Yang anda pilih bukan gambar.',
            ],
        ],
    ])) 
    {
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    $fileprofile = $this->request->getFile('pp');
    if ($fileprofile->getError() == 4) {
        $namaprofile = 'default.png';
    } else {
        $namaprofile = $fileprofile->getRandomName();
        $fileprofile->move('assets/img', $namaprofile);
    }

    $slug = url_title($this->request->getVar('name'), '-', true);

    // Hash the password
    $hashedPassword = password_hash($this->request->getVar('password'), PASSWORD_BCRYPT);

    $this->UserModels->save([
        'nama'          => $this->request->getVar('name'),
        'username'      => $this->request->getVar('username'),
        'role_id'       => $this->request->getVar('role_id'),
        'slug'          => $slug,
        'is_active'     => 1,
        'id_status'     => 1,
        'password'      => $hashedPassword,
        'image'         => $namaprofile,
    ]); 

    return redirect()->to('Registrasi')->with('message', 'Data berhasil ditambah');
}
 

    public function edit($id)
    {
        $session = session();
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $username       = $session->get('username');
        $akses          = session()->get('role_id');
        $roleModel      = new RoleModels();
        $userModels     = new UserModels();

        $user           = $userModels->where('username', $username)->first();
        $role_id        = $roleModel->find($user['role_id']);        
        
        $data['us']     = $userModels->find($id);
        $dat_status     = $this->StatusModels->findAll();
        $rol_id        = $this->RoleModels->findAll();

  
        if (!$data) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('User not found');
        }

        $data = [
            'title'             => '- Edit User',
            'judul'             => 'Registrasi',
            'rol_id'            => $rol_id,
            'role_id'           => $role_id,
            'dat_status'        => $dat_status,
            'us'                => $data,
            'user'              => $user,
            'akses'             => $akses 
        ];
         
        if ($akses == 1)
        {    
        echo view('tempt_us/header', $data);
        echo view('tempt_us/topbar');
        echo view('tempt_us/sidebar',$data);
        echo view('profile/edit_profile', $data);
        echo view("tempt_us/footer");
        } else {
            return redirect()->to('/restricted')->with('error', 'Anda tidak berhak mengakses halaman ini');
        }
    }

    
    public function update($id)
{
    $userModels = new UserModels();
    $data['user'] = $userModels->find($id);

    // Validasi input
    if (!$this->validate([
        'nama' => [
            'rules' => 'required|trim',
            'errors' => [
                'required' => 'Nama wajib diisi.',
            ],
        ],
        'username' => [
            'rules' => "required|trim|is_unique[user.username,id,{$id}]",
            'errors' => [
                'required' => 'Username wajib diisi.',
                'is_unique' => 'Username sudah ada.', 
            ],
        ],
        'role_id' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Job Position wajib diisi.',
            ],
        ],
        'status' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Status wajib terisi.',
            ],
        ],
        'pp' => [
            'rules' => 'permit_empty|uploaded[pp]|max_size[pp,2048]|is_image[pp]|mime_in[pp,image/jpg,image/jpeg,image/png]',
            'errors' => [
                'uploaded' => 'Pilih Foto profile.',
                'max_size' => 'Ukuran gambar terlalu besar.',
                'is_image' => 'File harus berupa gambar.',
                'mime_in' => 'Yang anda pilih bukan gambar.',
            ],
        ],
    ])) {
        return redirect()->back()->withInput();
    }

    // Ambil file gambar Upload 
    $photo_profile = $this->request->getFile('pp');
    $name_photo = $data['user']['image']; // Default to existing image

    if ($photo_profile && $photo_profile->isValid() && !$photo_profile->hasMoved()) {
        $name_photo = $photo_profile->getRandomName();
        $photo_profile->move('assets/img/user', $name_photo);

        // Hapus gambar lama jika ada gambar baru yang diupload dan gambar lama bukan default
        if ($data['user']['image'] != 'default.png' && file_exists('assets/img/user/' . $data['user']['image'])) {
            unlink('assets/img/user/' . $data['user']['image']);
        }
    }

    // Buat slug dari nama
    $slug = url_title($this->request->getVar('nama'), '-', true);

    // Update data user
    $userModels->update($id, [
        'nama' => $this->request->getVar('nama'),
        'slug' => $slug,
        'username' => $this->request->getVar('username'),
        'role_id' => $this->request->getVar('role_id'),
        'image' => $name_photo,
        'id_status' => $this->request->getVar('status')
    ]);

    return redirect()->to('Registrasi')->with('message', 'Data berhasil diupdate');
}

public function reset_password($id)
{
    $userModels = new UserModels();

    // Temukan user berdasarkan id 
    $user = $userModels->find($id);
    if(!$user)
    {
        return redirect()->back()->with('errors', 'User tidak ditemukan');
    }

    // Reset password menjadi default
    $defaultPassword    = 'Polulu_Official';
    $hashedPassword     = password_hash($defaultPassword, PASSWORD_DEFAULT);

    $userModels->update($id, ['password' => $hashedPassword]);

    return redirect()->back()->with('message', 'Password berhasil di reset');
}


    // public function logout()
    // {
    //     $session = session();
    //     session()->destroy();
    //     return redirect()->to('Login')->with('message', 'Logout Berhasil');
    // }
}
 
 