<?php

namespace App\Controllers;

use App\Models\UserModels; 
use App\Models\RoleModels;

class BankData extends BaseController
{ 
    public function __construct()
    {
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor
    }

    public function index() 
    { 
        $session = session();
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $akses     = session()->get('role_id');

        $username  = $session->get('username');

        $userModel = new UserModels();
        $roleModel = new RoleModels();
        $username  = session()->get('username');
        
        // Mengambil data pengguna
        $user       = $userModel->where('username', $username)->first();
        $role_id    = $roleModel->find($user['role_id']);

        $data = [
            'title'     => '- Master Data',
            'judul'		=> 'Master Data',
            'user'      => $user,
            'role_id'   => $role_id,
            'akses'     => $akses
        ];

        if($akses == 1 || $akses == 2)
        {
            echo view('tempt_us/header', $data);
            echo view('tempt_us/topbar');
            echo view('tempt_us/sidebar');
            echo view('bankdata');
            echo view("tempt_us/footer");
        } else {
            return redirect()->to('/restricted')->with('error', 'Anda tidak berhak mengakses halaman ini');
        }
    }
}