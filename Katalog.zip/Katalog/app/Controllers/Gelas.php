<?php
 
namespace App\Controllers;

class Gelas extends BaseController
{ 
    public function index() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas dan Mugs'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Gelas');
        echo view("tempt_us/footer");
    }

    public function gelas_hisap() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Hisap'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/gelas_hisap');
        echo view("tempt_us/footer");
    }

    public function gelas_kentang() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Kentang'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/kentang');
        echo view("tempt_us/footer");
    }

    public function gelas_kopi() 

    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Kentang'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/kopi');
        echo view("tempt_us/footer");
    }

    public function gelas_miring() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Miring'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/miring');
        echo view("tempt_us/footer");
    }

    public function gelas_piala() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas piala'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/piala');
        echo view("tempt_us/footer");
    }

    public function gelas_piala_terbaru() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas piala'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/piala2');
        echo view("tempt_us/footer");
    }

    public function gelas_takar() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Takar'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/takar');
        echo view("tempt_us/footer");
    }

    public function gelas_karakter() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Karakter'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/mug_karakter');
        echo view("tempt_us/footer");
    }

    public function gelas_karakter_polulu() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Gelas Karakter Polulu'
        ];

        echo view('tempt_us/header', $data);
        echo view('gelas/mug_polulu');
        echo view("tempt_us/footer");
    }
}
  
