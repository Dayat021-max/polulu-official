<?php

namespace App\Controllers;

class Sumpit extends BaseController
{ 
    public function index()
    {
        $data = [
            'title'     => '- Sumpit'
        ];
        echo view('tempt_us/header', $data); 
        echo view('display/d_Sumpit');
        echo view("tempt_us/footer");
    }

    public function polulu_ho()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Helm Oranye'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/polulu_ho');
        echo view("tempt_us/footer");
    }

    public function polulu_hb()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Helm Biru'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/polulu_hb');
        echo view("tempt_us/footer");
    }

     public function polulu_bear()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Beruang'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/polulu_bear');
        echo view("tempt_us/footer");
    }

    public function bean()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Bean'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/bean');
        echo view("tempt_us/footer");
    }

    public function Polulu_tiger()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Tiger'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/tiger');
        echo view("tempt_us/footer");
    }

    public function Polulu_koala()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Koala'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/koala');
        echo view("tempt_us/footer");
    }

    public function Gduck()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit G Duck Kids'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/duckbiru');
        echo view("tempt_us/footer");
    }

    public function Buaya()
    {
        $data = [
            'title'     => '- Sumpit',
            'judul'     => 'Sumpit Polulu Buaya'
        ];
        echo view('tempt_us/header', $data); 
        echo view('sumpit/buaya');
        echo view("tempt_us/footer");
    }
} 