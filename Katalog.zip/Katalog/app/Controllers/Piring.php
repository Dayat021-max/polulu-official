<?php

namespace App\Controllers;

class Piring extends BaseController
{  
    public function index() 
    { 
        $data = [
            'title'     => '- Piring'
        ]; 

        echo view('tempt_us/header', $data);
        echo view('display/d_Piring');
        echo view("tempt_us/footer");
    }

    public function Piring_Astronot() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Astronot'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/astronot');
        echo view("tempt_us/footer");
    }

    public function Piring_beruang() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Beruang'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/beruang');
        echo view("tempt_us/footer");
    }

    public function Piring_kepiting() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Kepiting'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/kepiting');
        echo view("tempt_us/footer");
    }

    public function Piring_kucing() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Kucing'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/kucing');
        echo view("tempt_us/footer");
    }

    public function Piring_lebah() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Lebah'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/lebah');
        echo view("tempt_us/footer");
    }

    public function Piring_monyet() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Monyet'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/monyet');
        echo view("tempt_us/footer");
    }

    public function Piring_Oneset() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring One Set'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/oneset');
        echo view("tempt_us/footer");
    }

    public function Piring_Tertawa()  
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Tertawa'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/ketawa');
        echo view("tempt_us/footer");
    }

    public function Piring_Tertawa_Kuping() 
    { 
        $data = [
            'title'     => '- Piring',
            'judul'     => ' Piring Tertawa Kuping'
        ];

        echo view('tempt_us/header', $data);
        echo view('piring/tertawa_gagang');
        echo view("tempt_us/footer");
    }
        
}
 
