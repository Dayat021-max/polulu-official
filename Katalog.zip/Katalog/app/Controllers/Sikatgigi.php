<?php
 
namespace App\Controllers;

class Sikatgigi extends BaseController
{ 
    public function index()
    {

        $data = [
            'title'     => '- Sikat Gigi'
        ];

        echo view('tempt_us/header', $data); 
        echo view('display/d_Sikatgigi');
        echo view("tempt_us/footer");
    }
 
    public function singa()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Singa'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/singa');
        echo view("tempt_us/footer");
    }

    public function paw()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Singa Paw'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/paw');
        echo view("tempt_us/footer");
    }

    public function serigala()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Serigala'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/serigala');
        echo view("tempt_us/footer");
    }

    public function polulu_small()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Polulu Small'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/polulu_small');
        echo view("tempt_us/footer");
    }

    public function love()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Love'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/love');
        echo view("tempt_us/footer");
    }

    public function buaya()
    {

        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Love'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/buaya');
        echo view("tempt_us/footer");
    }

    public function cocomelon()
    {

        $data = [
            'title'     => '- Sikat Gigi', 
            'judul'     => 'Sikat Gigi Cocomelon'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/cocomelon');
        echo view("tempt_us/footer");
    }

    public function kaki_dino()
    {
        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Dino Polos'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/Kaki_dino');
        echo view("tempt_us/footer");
    }

    public function jerapah()
    {
        $data = [
            'title'     => '- Sikat Gigi',
            'judul'     => 'Sikat Gigi Jerapah'
        ];

        echo view('tempt_us/header', $data); 
        echo view('sikat_gigi/jerapah');
        echo view("tempt_us/footer");
    }
}  