<?php
 
namespace App\Controllers; 
 
use App\Models\UserModels;
use App\Models\ItemModels;
use App\Models\KategoriModels;
use App\Models\RoleModels;
  
class Dashboard extends BaseController 
{ 
    protected $UserModels;
    protected $RoleModels;
    protected $ItemModels;
    protected $KategoriModels; 

    public function __construct()
    {
        $this->UserModels       = new UserModels();
        $this->RoleModels       = new RoleModels();
        $this->ItemModels       = new ItemModels();
        $this->KategoriModels   = new KategoriModels();
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor 
    }
      
    public function index() 
    {
        $session = session();
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        } 
        $kategori           = new KategoriModels();
        $itemModel          = new ItemModels();
        $kateogriCount      = $kategori->getCount();
        $itemCount = $itemModel->getCount();

        $akses      = session()->get('role_id');

        $username = $session->get('username');
        
        $userModel = new UserModels();
        $roleModel = new RoleModels();

        $user = $userModel->where('username', $username)->first();
        $role_id = $roleModel->find($user['role_id']);

        $data = [
            'title'     => 'Dashboard',
            'user'      => $user,
            'role_id'   => $role_id,
            'akses'     => $akses,
            'itemCount' => $itemCount,
            'kateogriCount' => $kateogriCount
        ];
 
        echo view('tempt_us/header', $data);
        echo view('tempt_us/topbar', $data);
        echo view('tempt_us/sidebar');
        echo view('dashboard', $data);
        echo view("tempt_us/footer");
    }
}
 
 