<?php

namespace App\Controllers;

class Botol extends BaseController
{ 
    public function index() 
    { 
 
        $data = [
            'title'     => '- Botol'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Botol');
        echo view("tempt_us/footer");
    }

    public function B_beruang() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Beruang'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/beruang');
        echo view("tempt_us/footer");
    }

    public function kartun() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Beruang'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/kartun');
        echo view("tempt_us/footer");
    }

    public function chaojun() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Chaojun'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/chaojun');
        echo view("tempt_us/footer");
    }

    public function classic() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Classic'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/classic');
        echo view("tempt_us/footer");
    }

    public function haojun() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Haojun'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/haojun');
        echo view("tempt_us/footer");
    }

    public function kartun_gagang() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Kartun Handle'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/kartun_gagang');
        echo view("tempt_us/footer");
    }

    public function lucu() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Lucu'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/lucu');
        echo view("tempt_us/footer");
    }

    public function botol700ml() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Minum 700mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/700ml');
        echo view("tempt_us/footer");
    }

    public function polulu240() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Polulu Polos 240 Mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/polulu240');
        echo view("tempt_us/footer");
    }

    public function botol_polulu() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Polulu 240 & 340 mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/botol_polulu');
        echo view("tempt_us/footer");
    }

    public function botol_sapi() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Karakter Sapi 240 & 340 mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/sapi');
        echo view("tempt_us/footer");
    }

    public function botol_stiker() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Stiker 500mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/stiker');
        echo view("tempt_us/footer");
    }

    public function botol_stiker400() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Stiker 400mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/stiker400');
        echo view("tempt_us/footer");
    }

    public function botol_bebek() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Stiker 400mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/bebek');
        echo view("tempt_us/footer");
    }

    public function botol_kentangxi() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol Kentang XinTiger'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/kentangxi');
        echo view("tempt_us/footer");
    }

    public function botol_xintiger() 
    { 
 
        $data = [
            'title'     => '- Botol',
            'judul'     => 'Botol XinTiger'
        ];

        echo view('tempt_us/header', $data);
        echo view('botol/xintiger');
        echo view("tempt_us/footer");
    }


}
 
