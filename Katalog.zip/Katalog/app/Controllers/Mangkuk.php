<?php

namespace App\Controllers;

class Mangkuk extends BaseController
{ 
    public function index() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'		=> 'Produk Mangkuk'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('display/d_Mangkuk');
        echo view("tempt_us/footer");
    }

    public function mpasipp() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'		=> 'Mangkuk MPASIPP'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mpasipp');
        echo view("tempt_us/footer");
    }

    public function mpasi_beruang() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk MPASI Beruang'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mpasi_beruang');
        echo view("tempt_us/footer");
    }

    public function mpasi_bulat() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk MPASI Bulat'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mpasi_bulat');
        echo view("tempt_us/footer");
    }

    public function mpasi_kotak() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk MPASI Kotak'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mpasi_kotak');
        echo view("tempt_us/footer");
    }

    public function penghalus() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Penghalus tanpa merek'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/penghalus');
        echo view("tempt_us/footer");
    }

    public function penghalus_polulu() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Penghalus Polulu'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/penghalus_polulu');
        echo view("tempt_us/footer");
    }

    public function mangkuk_silikon() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Silikon'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mangkuk_silikon');
        echo view("tempt_us/footer");
    }

    public function mangkuk_daun() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Daun'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/daun');
        echo view("tempt_us/footer");
    }

    public function mangkuk_dino() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Dino'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/dino');
        echo view("tempt_us/footer");
    } 

    public function mangkuk_jupp() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Stainless steel Jupp'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/jupp');
        echo view("tempt_us/footer");
    }

    public function mangkuk_mahkota() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Mahkota'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mahkota');
        echo view("tempt_us/footer");
    }

    public function mangkuk_mahkota2() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Mahkota'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mahkota_2');
        echo view("tempt_us/footer");
    }

    public function mangkuk_MGBaby() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk MGBaby'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mgbaby');
        echo view("tempt_us/footer");
    }

    public function mangkuk_PoluluSS() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk MGBaby'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/poluluSS');
        echo view("tempt_us/footer");
    }

    public function mangkuk_Turku() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Turku Isolasi Air'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/turku');
        echo view("tempt_us/footer");
    }

    public function mangkuk_Turku_Double_Handle() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Turku Tahan Karat'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/turku2');
        echo view("tempt_us/footer");
    }

    public function mangkuk_Susu()  
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Susu'
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/mangkuk_susu');
        echo view("tempt_us/footer");
    }

    public function mangkuk_Susu_Single_Handle() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Susu '
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/turku_double');
        echo view("tempt_us/footer");
    }

    public function turku_penghangat() 
    { 
        $data = [
            'title'     => 'Mangkuk',
            'judul'     => 'Mangkuk Susu '
        ]; 

        echo view('tempt_us/header', $data); 
        echo view('mangkuk/turku_penghangat');
        echo view("tempt_us/footer");
    }
}