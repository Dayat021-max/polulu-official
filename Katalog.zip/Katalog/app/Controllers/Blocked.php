<?php

namespace App\Controllers;

class Blocked extends BaseController 
{
    public function restricted()
    {
        echo "Access denied. You do not have permission to access this page.";
    }
}
 