<?php

namespace App\Controllers;

class Silikon extends BaseController
{ 
    public function index()  
    { 

        $data = [
            'title'     => '- Silikon'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Silikon');
        echo view("tempt_us/footer");
    }

    public function xin() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Sendok Xin Tinger'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/xin');
        echo view("tempt_us/footer");
    }

    public function polulu_merah() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Sendok Polulu Merah'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/PL_merah');
        echo view("tempt_us/footer");
    }

    public function Sendok_Turku() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Sendok Polulu Merah'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/s_turku');
        echo view("tempt_us/footer");
    }

    public function sendok_kotak() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Sendok Kotak'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/sendok_kotak');
        echo view("tempt_us/footer");
    }

    public function dual_varian() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Dual Varian'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/dual_varian');
        echo view("tempt_us/footer");
    }

    public function xin_love() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Dual Varian'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/xin_love');
        echo view("tempt_us/footer");
    }

    public function sendok_pinguin() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Dual Varian'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/sendok_pinguin');
        echo view("tempt_us/footer");
    }

    public function sendok_judo() 
    { 

        $data = [
            'title'     => '- Silikon',
            'judul'     => 'Dual Varian'
        ];

        echo view('tempt_us/header', $data);
        echo view('silikon/sendok_judo');
        echo view("tempt_us/footer");
    }

}
 
