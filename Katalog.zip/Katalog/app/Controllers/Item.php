<?php
 
namespace App\Controllers;
 
use App\Models\KategoriModels;
use App\Models\ItemModels;
use App\Models\UserModels;
use App\Models\RoleModels;
use CodeIgniter\Exceptions\PageNotFoundException; 

class Item extends BaseController
{
    protected $KategoriModels;
    protected $ItemModels;
    protected $UserModels;

    public function __construct() 
    {
        $this->KategoriModels = new KategoriModels();
        $this->ItemModels = new ItemModels();
        $this->UserModels = new UserModels();
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor

    }

    public function index()  
    {  
        $session = session(); 
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $user       = session()->get('id');
        $username = session()->get('username');
        $akses      = session()->get('role_id');
        $roleModel = new RoleModels();
        $userModel = new UserModels();

        
 
        // Mengambil data pengguna
        $user   = $userModel->where('username', $username)->first();
        $role_id= $roleModel->find($user['role_id']);

        $users           = $this->UserModels->findAll();
        $dat_item       = $this->ItemModels->findAll();
        $dat_kategori   = $this->KategoriModels->findAll();

        $data = [
            'title'            => '- Data Item',
            'judul'		       => 'Data Item',
            'dat_kategori'     => $dat_kategori,
            'dat_item'         => $dat_item,
            'user'             => $user,
            'users'            => $users,
            'role_id'          => $role_id,
            'akses'            => $akses
        ];

        if(!$data['dat_item']) 
        {
            throw PageNotFoundException::forPageNotFound();
        }

        if(!$data['dat_kategori'])
        {
            throw PageNotFoundException::forPageNotFound();
        }

        if($akses == 1 || $akses == 2 )
        {
        echo view('tempt_us/header', $data);
        echo view('tempt_us/topbar');
        echo view('tempt_us/sidebar', $data);
        echo view('data/item', $data);
        echo view("tempt_us/footer"); 
        } else {
             return redirect()->to('/restricted')->with('error', 'Anda tidak berhak mengakses halaman ini');

        } 
    }       


    public function Create() 
    { 
        $session = session();
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $nama       = session()->get('id');
        $akses      = session()->get('role_id');
        $username   = session()->get('username');

        $userModel = new UserModels();

        // Mengambil data pengguna
        $user       = $userModel->where('username', $username)->first();
        $nama       = $userModel->where('username', $username)->first();

        $dat_kategori =  $this->KategoriModels->findAll();

        $data = [
            'title'            => '- Data Item',
            'judul'            => 'Tambah Data Item',
            'dat_kategori'     => $dat_kategori,
            'akses'            => $akses,
            'nama'             => $nama
        ];

        if( $akses == 1 || $akses == 2)
        {
        echo view('tempt_us/header', $data);
        echo view('item/create_item',$data);
        // echo view("tempt_us/footer");    
        } else {
            return redirect()->to('/restricted')->with('error','Anda tidak berhak mengakses halaman ini.');
        }

    }

     public function save()
    {

        var_dump($this->request->getPost());
        /*Validasi Input*/
        if(!$this->validate([
            'produk'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Nama Produk Wajib diisi.',
                ],
            ],
            'kategori'      =>[
                'rules'     =>'required',
                'errors'    =>[
                    'required'  => 'Harus Pilih Kategori',
                ],
            ],
            'harga_eceran'  =>[
                'rules'     => 'required|decimal',
                'errors'    =>[
                    'required'  => 'Harga Ecer Harus diisi.',
                    'decimal'   => 'Selain Angka, Dilarang isi.',
                ],
            ],
            'harga_grosir1' =>[
                'rules'     => 'required|decimal',
                'errors'    =>[
                    'required'  => 'Harga Ecer Harus diisi.',
                    'decimal'   => 'Selain Angka, Dilarang isi.',
                ],
            ],
            'harga_grosir2' =>[
                'rules'     => 'required|decimal',
                'errors'    =>[
                    'required'  => 'Harga Ecer Harus diisi.',
                    'decimal'   => 'Selain Angka, Dilarang isi.',
                ],
            ],
            'harga_grosir3' =>[
                'rules'     => 'required|decimal',
                'errors'    =>[
                    'required'  => 'Harga Ecer Harus diisi.',
                    'decimal'   => 'Selain Angka, Dilarang isi.',
                ],
            ],
            'judul'         =>[
                'rules'     => 'max_size[judul,5048]|is_image[judul]|mime_in[judul,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto1'         =>[
                'rules'     => 'max_size[foto1,5048]|is_image[foto1]|mime_in[foto1,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto2'         =>[
                'rules'     => 'max_size[foto2,5048]|is_image[foto2]|mime_in[foto2,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto3'         =>[
                'rules'     => 'max_size[foto3,5048]|is_image[foto3]|mime_in[foto3,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto4'         =>[
                'rules'     => 'max_size[foto4,5048]|is_image[foto4]|mime_in[foto4,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto5'         =>[
                'rules'     => 'max_size[foto5,5048]|is_image[foto5]|mime_in[foto5,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto6'         =>[
                'rules'     => 'max_size[foto6,5048]|is_image[foto6]|mime_in[foto6,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto7'         =>[
                'rules'     => 'max_size[foto7,5048]|is_image[foto7]|mime_in[foto7,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto8'         =>[
                'rules'     => 'max_size[foto8,5048]|is_image[foto8]|mime_in[foto8,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'foto9'         =>[
                'rules'     => 'max_size[foto9,5048]|is_image[foto9]|mime_in[foto9,image/jpg,image/jpeg,image/png]',
                'errors'    =>[
                    'max_size'  => 'Ukuran tidak boleh terlalu besar',
                    'is_image'  => 'File harus berupa gambar',
                    'mime_in'   => 'Yang anda pilih bukan gambar',
                ],
            ],
            'p_model'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Produk Model Wajib diisi.',
                ],
            ],
            'p_size'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Produk Size Wajib diisi.',
                ],
            ],
            'p_material'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Material Produk Wajib diisi.',
                ],
            ],
            'p_kapasitas'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Kapasitas Produk Wajib diisi.',
                ],
            ],
            'p_warna'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Warna Produk Wajib diisi.',
                ],
            ],
            'keterangan'        =>[
                'rules'     =>'required',
                'errors'    => [
                    'required'  => 'Keterangan Produk Wajib diisi.',
                ],
            ],
        ])) {
            return redirect()->back()->withInput();
            }

            /*Ambil File Gambar*/
            $judul  =   $this->request->getFile('judul');
            if($judul->getError() == 4)
            {
                $name_judul = 'default.png';
            } else {
                $name_judul = $judul->getRandomName();
                $judul->move('assets/img/item', $name_judul);
            }

            /*Ambil File Gambar 1*/
            $foto1  =   $this->request->getFile('foto1');
            if($foto1->getError() == 4)
            {
                $foto_1 = 'default.png';
            } else {
                $foto_1 = $foto1->getRandomName();
                $foto1->move('assets/img/item', $foto_1);
            }

            /*Ambil File Gambar 2*/
            $foto2  =   $this->request->getFile('foto2');
            if($foto2->getError() == 4)
            {
                $foto_2 = 'default.png';
            } else {
                $foto_2 = $foto2->getRandomName();
                $foto2->move('assets/img/item', $foto_2);
            }

            /*Ambil File Gambar 3*/
            $foto3  =   $this->request->getFile('foto3');
            if($foto3->getError() == 4)
            {
                $foto_3 = 'default.png';
            } else {
                $foto_3 = $foto3->getRandomName();
                $foto3->move('assets/img/item', $foto_3);
            }

            /*Ambil File Gambar 4*/
            $foto4  =   $this->request->getFile('foto4');
            if($foto4->getError() == 4)
            {
                $foto_4 = 'default.png';
            } else {
                $foto_4 = $foto4->getRandomName();
                $foto4->move('assets/img/item', $foto_4);
            }

            /*Ambil File Gambar 5*/
            $foto5  =   $this->request->getFile('foto5');
            if($foto5->getError() == 4)
            {
                $foto_5 = 'default.png';
            } else {
                $foto_5 = $foto5->getRandomName();
                $foto5->move('assets/img/item', $foto_5);
            }

            /*Ambil File Gambar 6*/
            $foto6  =   $this->request->getFile('foto6');
            if($foto6->getError() == 4)
            {
                $foto_6 = 'default.png';
            } else {
                $foto_6 = $foto6->getRandomName();
                $foto6->move('assets/img/item', $foto_6);
            }

            /*Ambil File Gambar 7*/
            $foto7  =   $this->request->getFile('foto7');
            if($foto7->getError() == 4)
            {
                $foto_7 = 'default.png';
            } else {
                $foto_7 = $foto7->getRandomName();
                $foto7->move('assets/img/item', $foto_7);
            }

            /*Ambil File Gambar 8*/
            $foto8  =   $this->request->getFile('foto8');
            if($foto8->getError() == 4)
            {
                $foto_8 = 'default.png';
            } else {
                $foto_8 = $foto8->getRandomName();
                $foto8->move('assets/img/item', $foto_8);
            }

            /*Ambil File Gambar 9*/
            $foto9  =   $this->request->getFile('foto9');
            if($foto9->getError() == 4)
            {
                $foto_9 = 'default.png';
            } else {
                $foto_9 = $foto9->getRandomName();
                $foto9->move('assets/img/item', $foto_9);
            }

                 // Ambil input nomor faktur
            $barcode = $this->request->getPost('barcode');

            // Cek jika nomor faktur kosong, maka generate nomor faktur baru
            if (empty($barcode)) {
                $barcode = $this->generateBarcode();
            }


            // Buat slug dari nama kategori
            $slug = url_title($this->request->getVar('produk'), '-', true);

            $this->ItemModels->save([
                'produk'            => $this->request->getVar('produk'),
                'slug'              => $slug,
                'id_kategori'       => $this->request->getVar('kategori'),
                'id_user'           => $this->request->getVar('user'),
                'barcode'           => $barcode,
                'harga_eceran'      => $this->request->getVar('harga_eceran'),
                'harga_grosir1'     => $this->request->getVar('harga_grosir1'),
                'harga_grosir2'     => $this->request->getVar('harga_grosir2'),
                'harga_grosir3'     => $this->request->getVar('harga_grosir3'),
                'judul'             => $name_judul,
                'foto1'             => $foto_1,
                'foto2'             => $foto_2,
                'foto3'             => $foto_3,
                'foto4'             => $foto_4,
                'foto5'             => $foto_5,
                'foto6'             => $foto_6,
                'foto7'             => $foto_7,
                'foto8'             => $foto_8,
                'foto9'             => $foto_9,
                'produk_model'      => $this->request->getVar('p_model'),
                'produk_size'       => $this->request->getVar('p_size'),
                'produk_material'   => $this->request->getVar('p_material'),
                'produk_kapasitas'  => $this->request->getVar('p_kapasitas'),
                'produk_warna'      => $this->request->getVar('p_warna'),
                'keterangan'        => $this->request->getVar('keterangan'),
            ]);

            return redirect()->to('Item')->with('message', 'Data Berhasil ditambah');
    }

    private function generateBarcode()
    {
        $prefix = '899';
        $random1 = $this->generateRandomNumber(4); // Random 4-digit number
        $random2 = $this->generateRandomNumber(4); // Random 4-digit number
        $suffix = '2';

        return "$prefix$random1$random2$suffix";
    }

    private function generateRandomNumber($length)
    {
        $randomNumber = '';
        for ($i = 0; $i < $length; $i++) {
            $randomNumber .= rand(0, 9); // Menghasilkan digit acak antara 0 sampai 9
        }
        return $randomNumber;
    }
 
    public function preview($id)
    {   
        $session = session();
        $akses   = session()->get('role_id');
        $itemModel  = new ItemModels();  
        $data['Item']       = $itemModel->find($id); 


        if (!$data) {
            throw PageNotFoundException::forPageNotFound();
        }

        $data = [ 
            'title'     => 'Detail Item',
            'akses'     => $akses,
            'Item'      => $data
        ];

        if($akses == 1 || $akses == 2 )
        {
        echo view('tempt_us/header', $data);
        echo view('item/preview_item', $data);
        // echo view("tempt_us/footer"); 
        } else {
            return redirect()->to('/restricted')->with('error','Anda tidak berhak mengakses halaman ini.');
        }
    } 

    public function update_item($id) 
    {   
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }
        
        $userModel  = new UserModels();
        $session    = session();
        $akses      = session()->get('role_id');
        $nama       = session()->get('id');
        $username   = session()->get('username');
        $itemModel  = new ItemModels();
        $data['Item']       = $itemModel->find($id);
        $dat_kategori =  $this->KategoriModels->findAll();
        $nama       = $userModel->where('username', $username)->first();


        if (!$data) {
            throw PageNotFoundException::forPageNotFound();
        }
 
        $data = [
            'title'         => 'Detail Item',
            'judul'         => 'Tambah Data Item',
            'Item'          => $data,
            'dat_kategori'  => $dat_kategori,
            'akses'         => $akses,
            'nama'          => $nama
        ];

        if($akses == 1 || $akses == 2 )
        {
        echo view('tempt_us/header', $data);
        echo view('item/update_item', $data);
        /*echo view("tempt_us/footer"); */
        } else {
            return redirect()->to('/restricted')->with('error','Anda tidak berhak mengakses halaman ini.');
        }
    } 
 
    public function update($id)
{
    $itemModel = new ItemModels();
    $data['item'] = $itemModel->find($id);
    
    // Validasi Input
    if (!$this->validate([
        'produk' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Nama Produk Wajib diisi.',
            ],
        ],
        'kategori' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Nama Kategori Wajib diisi.',
            ],
        ],
        'harga_eceran' => [
            'rules' => 'required|decimal',
            'errors' => [
                'required' => 'Harga eceran Wajib diisi.',
                'decimal' => 'Harga eceran harus berupa angka.',
            ],
        ],
        'harga_grosir1' => [
            'rules' => 'required|decimal',
            'errors' => [
                'required' => 'Harga grosir 1 Wajib diisi.',
                'decimal' => 'Harga grosir 1 harus berupa angka.',
            ],
        ],
        'harga_grosir2' => [
            'rules' => 'required|decimal',
            'errors' => [
                'required' => 'Harga grosir 2 Wajib diisi.',
                'decimal' => 'Harga grosir 2 harus berupa angka.',
            ],
        ],
        'harga_grosir3' => [
            'rules' => 'required|decimal',
            'errors' => [
                'required' => 'Harga grosir 3 Wajib diisi.',
                'decimal' => 'Harga grosir 3 harus berupa angka.',
            ],
        ],
        'judul' => [
            'rules' => 'max_size[judul,6144]|is_image[judul]|mime_in[judul,image/jpg,image/jpeg,image/png]',
            'errors' => [
                'max_size' => 'Ukuran tidak boleh terlalu besar',
                'is_image' => 'File harus berupa gambar',
                'mime_in' => 'Yang anda pilih bukan gambar',
            ],
        ],
        // Tambahkan validasi untuk foto lainnya jika diperlukan
        'p_model' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Model Produk Wajib diisi.',
            ],
        ],
        'p_size' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Ukuran Produk Wajib diisi.',
            ],
        ],
        'p_material' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Material Produk Wajib diisi.',
            ],
        ],
        'p_kapasitas' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Kapasitas Produk Wajib diisi.',
            ], 
        ],
        'p_warna' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Warna Produk Wajib diisi.', 
            ], 
        ],
        'keterangan' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Keterangan Wajib diisi.',
            ],
        ],
    ])) {
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    /*--------- JUDUL ----------*/
    // Ambil file gambar Upload
    $gambar_judul = $this->request->getFile('judul');

    if ($gambar_judul && $gambar_judul->isValid() && !$gambar_judul->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_judul = $gambar_judul->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_judul->move('assets/img/item', $name_judul);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['judul'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['judul'])) {
            unlink('assets/img/item/' . $data['item']['judul']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_judul = $data['item']['judul'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $fileprofile = $this->request->getFile('judul');
    $namaprofile = $name_judul; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($fileprofile && $fileprofile->isValid() && !$fileprofile->hasMoved()) {
        $namaprofile = $fileprofile->getRandomName();
        $fileprofile->move('assets/img/item', $namaprofile);
    }

    /*--------- END JUDUL ----------*/


    /*--------- Foto 1 ----------*/
    // Ambil file gambar Upload
    $gambar_1 = $this->request->getFile('foto1');

    if ($gambar_1 && $gambar_1->isValid() && !$gambar_1->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_1 = $gambar_1->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_1->move('assets/img/item', $name_1);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto1'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto1'])) {
            unlink('assets/img/item/' . $data['item']['foto1']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_1 = $data['item']['foto1'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto1 = $this->request->getFile('foto1');
    $namafoto1 = $name_1; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto1 && $filefoto1->isValid() && !$filefoto1->hasMoved()) {
        $namafoto1 = $filefoto1->getRandomName();
        $filefoto1->move('assets/img/item', $namafoto1);
    }
    /*--------- Foto 1 ----------*/

    /*--------- Foto 2 ----------*/
    // Ambil file gambar Upload
    $gambar_2 = $this->request->getFile('foto2');

    if ($gambar_2 && $gambar_2->isValid() && !$gambar_2->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_2 = $gambar_2->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_2->move('assets/img/item', $name_2);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto2'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto2'])) {
            unlink('assets/img/item/' . $data['item']['foto2']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_2 = $data['item']['foto2'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto2 = $this->request->getFile('foto2');
    $namafoto2 = $name_2; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto2 && $filefoto2->isValid() && !$filefoto2->hasMoved()) {
        $namafoto2 = $filefoto2->getRandomName();
        $filefoto2->move('assets/img/item', $namafoto2);
    }
    /*--------- End Foto 2 ----------*/

    /*--------- Foto 3 ----------*/
    // Ambil file gambar Upload
    $gambar_3 = $this->request->getFile('foto3');

    if ($gambar_3 && $gambar_3->isValid() && !$gambar_3->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_3 = $gambar_3->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_3->move('assets/img/item', $name_3);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto3'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto3'])) {
            unlink('assets/img/item/' . $data['item']['foto3']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_3 = $data['item']['foto3'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto3 = $this->request->getFile('foto3');
    $namafoto3 = $name_3; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto3 && $filefoto3->isValid() && !$filefoto3->hasMoved()) {
        $namafoto3 = $filefoto3->getRandomName();
        $filefoto3->move('assets/img/item', $namafoto3);
    }
    /*--------- End Foto 3 ----------*/
    
    /*--------- Foto 4 ----------*/
    // Ambil file gambar Upload
    $gambar_4 = $this->request->getFile('foto4');

    if ($gambar_4 && $gambar_4->isValid() && !$gambar_4->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_4 = $gambar_4->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_4->move('assets/img/item', $name_4);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto4'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto4'])) {
            unlink('assets/img/item/' . $data['item']['foto4']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_4 = $data['item']['foto4'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto4 = $this->request->getFile('foto4');
    $namafoto4 = $name_4; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto4 && $filefoto4->isValid() && !$filefoto4->hasMoved()) {
        $namafoto4 = $filefoto4->getRandomName();
        $filefoto4->move('assets/img/item', $namafoto4);
    }
    /*--------- End Foto 4 ----------*/

    /*--------- Foto 5 ----------*/
    // Ambil file gambar Upload
    $gambar_5 = $this->request->getFile('foto5');

    if ($gambar_5 && $gambar_5->isValid() && !$gambar_5->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_5 = $gambar_5->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_5->move('assets/img/item', $name_5);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto5'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto5'])) {
            unlink('assets/img/item/' . $data['item']['foto5']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_5 = $data['item']['foto5'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto5 = $this->request->getFile('foto5');
    $namafoto5 = $name_5; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto5 && $filefoto5->isValid() && !$filefoto5->hasMoved()) {
        $namafoto5 = $filefoto5->getRandomName();
        $filefoto5->move('assets/img/item', $namafoto5);
    }
    /*--------- End Foto 5 ----------*/

    /*--------- Foto 6 ----------*/
    // Ambil file gambar Upload
    $gambar_6 = $this->request->getFile('foto6');

    if ($gambar_6 && $gambar_6->isValid() && !$gambar_6->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_6 = $gambar_6->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_6->move('assets/img/item', $name_6);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto6'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto6'])) {
            unlink('assets/img/item/' . $data['item']['foto6']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_6 = $data['item']['foto6'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto6 = $this->request->getFile('foto6');
    $namafoto6 = $name_6; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto6 && $filefoto6->isValid() && !$filefoto6->hasMoved()) {
        $namafoto6 = $filefoto6->getRandomName();
        $filefoto6->move('assets/img/item', $namafoto6);
    }
    /*--------- End Foto 6 ----------*/

    /*--------- Foto 7 ----------*/
    // Ambil file gambar Upload
    $gambar_7 = $this->request->getFile('foto7');

    if ($gambar_7 && $gambar_7->isValid() && !$gambar_7->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_7 = $gambar_7->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_7->move('assets/img/item', $name_7);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto7'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto7'])) {
            unlink('assets/img/item/' . $data['item']['foto7']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_7 = $data['item']['foto7'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto7 = $this->request->getFile('foto7');
    $namafoto7 = $name_7; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto7 && $filefoto7->isValid() && !$filefoto7->hasMoved()) {
        $namafoto7 = $filefoto7->getRandomName();
        $filefoto7->move('assets/img/item', $namafoto7);
    }
    /*--------- End Foto 7 ----------*/

    /*--------- Foto 8 ----------*/
    // Ambil file gambar Upload
    $gambar_8 = $this->request->getFile('foto8');

    if ($gambar_8 && $gambar_8->isValid() && !$gambar_8->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_8 = $gambar_8->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_8->move('assets/img/item', $name_8);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto8'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto8'])) {
            unlink('assets/img/item/' . $data['item']['foto8']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_8 = $data['item']['foto8'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto8 = $this->request->getFile('foto8');
    $namafoto8 = $name_8; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto8 && $filefoto8->isValid() && !$filefoto8->hasMoved()) {
        $namafoto8 = $filefoto8->getRandomName();
        $filefoto8->move('assets/img/item', $namafoto8);
    }
    /*--------- End Foto 8 ----------*/

    /*--------- Foto 9 ----------*/
    // Ambil file gambar Upload
    $gambar_9 = $this->request->getFile('foto9');

    if ($gambar_9 && $gambar_9->isValid() && !$gambar_9->hasMoved()) {
        // Nama acak untuk file yang di-upload
        $name_9 = $gambar_9->getRandomName();
        // Pindahkan file ke folder tujuan
        $gambar_9->move('assets/img/item', $name_9);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['item']['foto9'] != 'default.png' && file_exists('assets/img/item/' . $data['item']['foto9'])) {
            unlink('assets/img/item/' . $data['item']['foto9']);
        }
    } else {
        // Jika tidak ada gambar baru, gunakan nama gambar lama
        $name_9 = $data['item']['foto9'];
    }

    // Mengatur nama profile ke nama gambar yang telah ditentukan
    $filefoto9 = $this->request->getFile('foto9');
    $namafoto9 = $name_9; // Default ke nama gambar lama

    // Jika ada gambar baru yang diupload, proses dan pindahkan
    if ($filefoto9 && $filefoto9->isValid() && !$filefoto9->hasMoved()) {
        $namafoto9 = $filefoto9->getRandomName();
        $filefoto9->move('assets/img/item', $namafoto9);
    }
    /*--------- End Foto 9 ----------*/


    // Ambil input nomor faktur
    $barcode = $this->request->getPost('barcode');

    // Cek jika nomor faktur kosong, maka generate nomor faktur baru
    if (empty($barcode)) {
        $barcode = $this->generateBarcode();
    }
    // Buat slug dari nama produk
    $slug = url_title($this->request->getVar('produk'), '-', true);

    // Lakukan Update Data 
    $itemModel->update($id, [ 
        'produk'            => $this->request->getPost('produk'),
        'id_user'           => $this->request->getPost('user'),
        'slug' => $slug,
        'id_kategori' => $this->request->getPost('kategori'),
        'harga_eceran' => $this->request->getPost('harga_eceran'),
        'harga_grosir1' => $this->request->getPost('harga_grosir1'),
        'harga_grosir2' => $this->request->getPost('harga_grosir2'),
        'harga_grosir3' => $this->request->getPost('harga_grosir3'),
        'produk_model' => $this->request->getPost('p_model'),
        'produk_size' => $this->request->getPost('p_size'),
        'produk_material' => $this->request->getPost('p_material'),
        'produk_kapasitas' => $this->request->getPost('p_kapasitas'),
        'produk_warna' => $this->request->getPost('p_warna'),
        'keterangan' => $this->request->getPost('keterangan'),
        'barcode' => $barcode,
        'judul' => $namaprofile,
        'foto1' => $namafoto1,
        'foto2' => $namafoto2,
        'foto3' => $namafoto3,
        'foto4' => $namafoto4,
        'foto5' => $namafoto5,
        'foto6' => $namafoto6,
        'foto7' => $namafoto7,
        'foto8' => $namafoto8,
        'foto9' => $namafoto9,
        // Tambahkan kolom foto jika diperlukan
    ]);

    return redirect()->to('Item')->with('message', 'Data berhasil diupdate');
}

public function delete($id)
{
    // Logika penghapusan item berdasarkan $id
    $this->ItemModels->delete($id);
    
    // Memberikan respons yang sesuai (optional)
    return $this->response->setJSON(['success' => true]);
}



}
