<?php
 
namespace App\Controllers;
 
use App\Models\KategoriModels;
use App\Models\UserModels;
use App\Models\RoleModels;
use CodeIgniter\Exceptions\PageNotFoundException;

class Kategori extends BaseController  
{ 
    protected $KategoriModels;
    protected $UserModels;
    public function __construct() 
    { 
        $this->UserModels     = new UserModels();
        $this->KategoriModels = new KategoriModels(); 
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor
 
    }  

    public function index()
    {
        $session = session();
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $nama       = session()->get('id');
        $akses      = session()->get('role_id');
        $roleModel = new RoleModels();
        $userModel = new UserModels();
 
        $username  = session()->get('username');


        
        // Mengambil data pengguna
        $user       = $userModel->where('username', $username)->first();
        $nama       = $userModel->where('username', $username)->first();
        $role_id    = $roleModel->find($user['role_id']);
        $data['nama'] = $nama;

        $Kategori = $this->KategoriModels->findAll();
        $dat_kategori = $this->KategoriModels->findAll();
        $users      = $this->UserModels->findAll();

        $data = [
            'title'         => '- Kategori',
            'Kategori'      => $Kategori,  
            'dat_kategori'  => $dat_kategori,
            'user'          => $user,
            'users'         => $users,
            'role_id'       => $role_id,
            'akses'         => $akses,
            'nama'          => $nama

        ]; 

        /*jika kategori tidak ada di tabel*/
        if(!$data['Kategori'])
        {
            throw PageNotFoundException::forPageNotFound();
        }

        if( $akses == 1 || $akses == 2 )
        {
        echo view('tempt_us/header', $data);
        echo view('tempt_us/topbar');
        echo view('tempt_us/sidebar',$data);
        echo view('data/kategori', $data);
        echo view('tempt_us/footer');    
        }else{
            return redirect()->to('/restricted')->with('error', 'Anda tidak berhak mengakses halaman ini');
        }
    }

    public function save() 
{
    // Validasi input
    if(!$this->validate([
        'kategori' => [ 
            'rules' => 'required',
            'errors'=> [
                'required' => 'Nama kategori wajib diisi.',
            ],
        ],
        'kategori_foto' => [
            'rules' => 'max_size[kategori_foto,5048]|is_image[kategori_foto]|mime_in[kategori_foto,image/jpg,image/jpeg,image/png]',
            'errors'=> [
                'max_size'  => 'Ukuran tidak boleh terlalu besar',
                'is_image'  => 'File harus berupa gambar', 
                'mime_in'   => 'Yang anda pilih bukan gambar',
            ],
        ],
    ])) {
        return redirect()->to('/kategori')->withInput()->with('errors', $this->validator->getErrors());
    }

    // Ambil file gambar
    $katalog_profile = $this->request->getFile('kategori_foto');
    if($katalog_profile->getError() == 4) {
        $name_katalog = 'default.png';
    } else {
        $name_katalog = $katalog_profile->getRandomName();
        $katalog_profile->move('assets/img/kategori', $name_katalog);
    }

    // Buat slug dari nama kategori
    $slug = url_title($this->request->getVar('kategori'), '-', true);

    // Simpan data ke database
    $this->KategoriModels->save([
        'kategori'  => $this->request->getVar('kategori'),
        'slug'      => $slug,
        'img'       => $name_katalog,
        'id_user'   => $this->request->getVar('user')
    ]);

    return redirect()->to('/kategori')->with('message', 'Data berhasil ditambah');
}

    /*Comment sebentar*/

    public function update($id)
{
    $kategoriModel = new KategoriModels();
    $data['kategori'] = $kategoriModel->find($id);

    // Validasi input
    if (!$this->validate([
        'kategori' => [
            'rules' => 'required',
            'errors' => [
                'required' => 'Nama kategori wajib diisi.',
            ],
        ],
        'kategori_foto' => [
            'rules' => 'max_size[kategori_foto,5048]|is_image[kategori_foto]|mime_in[kategori_foto,image/jpg,image/jpeg,image/png]',
            'errors' => [
                'max_size' => 'Ukuran tidak boleh terlalu besar',
                'is_image' => 'File harus berupa gambar',
                'mime_in' => 'Yang anda pilih bukan gambar', 
            ],
        ],
    ])) {
        return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
    }

    // Ambil file gambar
    $katalog_profile = $this->request->getFile('kategori_foto');
    if ($katalog_profile->isValid() && !$katalog_profile->hasMoved()) {
        $name_katalog = $katalog_profile->getRandomName();
        $katalog_profile->move('assets/img/kategori', $name_katalog);

        // Hapus gambar lama jika ada gambar baru yang diupload
        if ($data['kategori']['img'] != 'default.png' && is_file('assets/img/kategori/' . $data['kategori']['img'])) {
            unlink('assets/img/kategori/' . $data['kategori']['img']);
        }
    } else {
        $name_katalog = $data['kategori']['img'];
    }

    // Lakukan update data
    $kategoriModel->update($id, [
        'kategori'  => $this->request->getPost('kategori'),
        'slug'      => url_title($this->request->getPost('kategori'), '-', true),
        'img'       => $name_katalog,
        'id_user'   => $this->request->getPost('user')
    ]);

    // Redirect dengan pesan sukses
    return redirect()->to('/kategori')->with('message', 'Data berhasil diupdate');
}



}
 