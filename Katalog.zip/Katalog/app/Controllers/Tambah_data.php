<?php
 
namespace App\Controllers;
use App\Models\UserModels;

class Tambah_data extends BaseController
{ 
    public function __construct()
    {
        $this->session = \Config\Services::session(); // Memuat session di dalam constructor
    }

    public function index()
    {
        // Periksa apakah session username tidak ada atau tidak set TRUE
        if (!$this->session->has('username')) {
            return redirect()->to('Login'); // Alihkan ke halaman Login jika tidak ada session username
        }

        $userModel = new UserModels();
        $username = session()->get('username');
        
        // Mengambil data pengguna
        $user = $userModel->where('username', $username)->first();
        $data = [
            'title'     => '- Tambah Data',
            'user'      => $user
        ];


        echo view('tempt_us/header', $data);
        echo view('tempt_us/topbar');
        echo view('tempt_us/sidebar');
        echo view('data/tambah_data');
        echo view("tempt_us/footer");
    }
}
 
  