<?php
 
namespace App\Controllers;
  
use App\Models\UserModels;
use App\Models\RoleModels;
use App\Models\AccessmenuModels;
use App\Models\SubmenuModels;
use App\Models\UsermenuModels;
use CodeIgniter\Controller;
  
class Sidebar extends BaseController 
{ 
	public function index()
	{ 
		// Inisialisasi session dan database
        $session = session();
        $role_id = $session->get('role_id');

        // Load model
        $menuModel = new MenuModel();
        $subMenuModel = new SubMenuModel();
        $userAccessMenuModel = new UserAccessMenuModel();

        // Query untuk mendapatkan menu berdasarkan role_id
        $menu = $menuModel->select('user_menu.id, menu')
                          ->join('user_access_menu', 'user_menu.id = user_access_menu.menu_id')
                          ->where('user_access_menu.role_id', $role_id)
                          ->orderBy('user_access_menu.menu_id', 'ASC')
                          ->findAll();

        // Query untuk mendapatkan submenu yang aktif berdasarkan menu ID
        foreach ($menu as &$m) {
            $m['subMenu'] = $subMenuModel->select('*')
                                         ->join('user_menu', 'user_sub_menu.menu_id = user_menu.id')
                                         ->where('user_sub_menu.menu_id', $m['id'])
                                         ->where('user_sub_menu.is_active', 1)
                                         ->findAll();
        }

        $data['menu'] = $this->menuModel->get_menu_data();
		return view('tempt_us/ Sidebar', $data);
	}
}