<?php
  
namespace App\Controllers; 

use App\Models\UserModels; 

class Login extends BaseController 
{ 
	public function index()
	{	
		if (session()->get('username')) 
		{
	        return redirect()->to('Dashboard');
	    }

	    $validation = \Config\Services::validation();

	    /*Set Rules for the from*/

	    $validation->setRules([
	    	'username'			=> [
	    		'label'			=> 'username',
	    		'rules'			=> 'required|trim|min_length[5]|max_length[20]',
	    		'errors'		=> [
	    			'required'	=> 'Username wajib diisi',
	    			'min_length'=> 'Tidak boleh kurang dari 5 huruf/angka.',
	    			'max_length'=> 'Tidak boleh lebih dari 20 huruf/angka.'
	    		]
	    	],
	    	'password'			=> [
	    		'label'			=> 'password',
	    		'rules'			=> 'required|trim|min_length[5]|max_length[20]',
	    		'errors'		=> [
	    			'required'	=> 'Username wajib diisi',
	    			'min_length'=> 'Tidak boleh kurang dari 5 huruf/angka.',
	    			'max_length'=> 'Tidak boleh lebih dari 20 huruf/angka.'
	    		]
	    	],	
	    ]);

	    if(!$this->request->getPost() || !$validation->withRequest($this->request)->run())
	    {
	    	$data['title'] 	= 'Login Page';
	    	echo view('tempt_us/header', $data);
	    	echo view('login');
	    	echo view('tempt_us/footer');
	    } else { 
	    	$this->access();
	    }
	}

	public function access()
	{
		$username		= $this->request->getPost('username');
		$password 		= $this->request->getPost('password');

		$userModels		= new UserModels();
		$user = $userModels->where('username', $username)->first();
 
		if($user)
		{ 
			if($user['is_active'] == 1 )
			{
				if(password_verify($password, $user['password']))
				{
					$data = [
						'username'	=> $user['username'],
						'role_id'	=> $user['role_id']
					];

					session()->set($data);
					return redirect()->to('Dashboard');
				} else {
					session()->setFlashdata('errors', 'Wrong password');
					return redirect()->to('Login');
				}
			} else {
				session()->setFlashdata('errors', 'Username Tidak Aktif');
				return redirect()->to('Login');
			}
		} else {
			session()->setFlashdata('errors', 'Username tidak terdaftar');
			return redirect()->to('Login');
		}
	} 

	public function logout()
	{
	    $session = session();
    // Set flash message before destroying the session
    session()->setFlashdata('message', 'Logout Berhasil');

    // Destroy the session
    session()->destroy();

    // Redirect to login page
    return redirect()->to('Login');
	}
}