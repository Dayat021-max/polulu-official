<?php
 
namespace App\Controllers;

class LunchBox extends BaseController
{ 
    public function index()  
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Lunch Box'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Lunch');
        echo view("tempt_us/footer");
    }

    public function lunch500() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal 500 Mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/lunch_500');
        echo view("tempt_us/footer");
    }

    public function lunch800() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal 800 Mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/lunch_800');
        echo view("tempt_us/footer");
    }

    public function lunch1400() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal 1400 Mili'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/lunch_1400');
        echo view("tempt_us/footer");
    }

    public function MPASI_dua_gagang() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal MPASI Dua Gagang'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/gagang');
        echo view("tempt_us/footer");
    }

    public function MPASI_PP() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal MPASI Dua Gagang'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/pp');
        echo view("tempt_us/footer");
    }

    public function paus() 
    {  
        $data = [
            'title'     => '- Gelas',
            'judul'     => 'Produk Kotak Bekal Paus'
        ];

        echo view('tempt_us/header', $data);
        echo view('lunch/paus');
        echo view("tempt_us/footer");
    }
}
  
