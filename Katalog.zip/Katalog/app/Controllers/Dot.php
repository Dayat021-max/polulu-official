<?php

namespace App\Controllers;

class Dot extends BaseController
{  
    public function index() 
    {  

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => 'Produk Dot dan Empeng'
        ];

        echo view('tempt_us/header', $data);
        echo view('display/d_Dot');
        echo view("tempt_us/footer");
    } 

    public function dot_beruang() 
    { 

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => ' Empeng Buah Beruang'
        ];

        echo view('tempt_us/header', $data);
        echo view('Dot/dot_beruang');
        echo view("tempt_us/footer");
    }

    public function dot_bulat() 
    { 

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => ' Empeng Bulat'
        ];

        echo view('tempt_us/header', $data);
        echo view('Dot/empeng_bulat');
        echo view("tempt_us/footer");
    } 

    public function dot_rantai() 
    { 

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => ' Empeng Bulat'
        ];

        echo view('tempt_us/header', $data);
        echo view('Dot/empeng_rantai');
        echo view("tempt_us/footer");
    }  

    public function dot_segitiga() 
    { 

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => ' Empeng Segitiga'
        ];

        echo view('tempt_us/header', $data);
        echo view('Dot/dot_segitiga');
        echo view("tempt_us/footer");
    } 

    public function dot_buah() 
    { 

        $data = [ 
            'title'     => '- Silikon',
            'judul'     => ' Empeng Buah'
        ];

        echo view('tempt_us/header', $data);
        echo view('Dot/dot_buah');
        echo view("tempt_us/footer");
    } 
}
 
