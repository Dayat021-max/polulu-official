<?php

use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\Database\ConnectionInterface;

function is_logged_in()  
{
    $session = session();  
    $request = service('request');
    $db = \Config\Database::connect();

    if (!$session->get('username')) {
        return redirect()->to('login');
    } else {
        $role_id = $session->get('role_id');
        $menu = $request->uri->getSegment(1);

        $queryMenu = $db->table('user_menu')->getWhere(['menu' => $menu])->getRowArray();

        if ($queryMenu) {
            $menu_id = $queryMenu['id'];
            $userAccess = $db->table('user_access_menu')
                ->where('role_id', $role_id)
                ->where('menu_id', $menu_id)
                ->countAllResults();

            if ($userAccess < 1) {
                return redirect()->to('login/blocked');
            }
        } else {
            return redirect()->to('login/blocked');
        }
    }
}
