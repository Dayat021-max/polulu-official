<?php

use CodeIgniter\Router\RouteCollection;  
  
/**  
 * @var RouteCollection $routes    
 */
$routes->get('/', 'Landpage::index'); 
$routes->get('/Landpage', 'Landpage::index');
$routes->get('/Landpage/list/(:num)', 'Landpage::list/$1'); 
$routes->get('/Landpage/view/(:num)', 'Landpage::view/$1'); 
  
   

$routes->get('Sikatgigi','Sikatgigi::index');
$routes->get('Sikatgigi/singa','Sikatgigi::singa');
$routes->get('Sikatgigi/paw','Sikatgigi::paw');
$routes->get('Sikatgigi/serigala','Sikatgigi::serigala');
$routes->get('Sikatgigi/polulu_small','Sikatgigi::polulu_small');
$routes->get('Sikatgigi/love','Sikatgigi::love');
$routes->get('Sikatgigi/buaya','Sikatgigi::buaya');
$routes->get('Sikatgigi/cocomelon','Sikatgigi::cocomelon');
$routes->get('Sikatgigi/kaki_dino','Sikatgigi::kaki_dino');
$routes->get('Sikatgigi/jerapah','Sikatgigi::jerapah');

   
 
$routes->get('Sumpit','Sumpit::index'); 
$routes->get('Sumpit/polulu_ho','Sumpit::polulu_ho'); 
$routes->get('Sumpit/polulu_hb','Sumpit::polulu_hb'); 
$routes->get('Sumpit/polulu_bear','Sumpit::polulu_bear');  
$routes->get('Sumpit/bean','Sumpit::bean'); 
$routes->get('Sumpit/polulu_tiger','Sumpit::polulu_tiger');
$routes->get('Sumpit/polulu_koala','Sumpit::polulu_koala');  
$routes->get('Sumpit/Gduck','Sumpit::Gduck');
$routes->get('Sumpit/Buaya','Sumpit::Buaya');

   
$routes->get('Silikon','Silikon::index');
$routes->get('Silikon/xin','Silikon::xin');
$routes->get('Silikon/polulu_merah','Silikon::polulu_merah');
$routes->get('Silikon/Sendok_Turku','Silikon::Sendok_Turku');
$routes->get('Silikon/sendok_kotak','Silikon::sendok_kotak');
$routes->get('Silikon/dual_varian','Silikon::dual_varian');
$routes->get('Silikon/xin_love','Silikon::xin_love');
$routes->get('Silikon/sendok_pinguin','Silikon::sendok_pinguin');
$routes->get('Silikon/sendok_judo','Silikon::sendok_judo');

 

$routes->get('Mangkuk','Mangkuk::index');
$routes->get('Mangkuk/mpasipp','Mangkuk::mpasipp');
$routes->get('Mangkuk/mpasi_beruang','Mangkuk::mpasi_beruang');
$routes->get('Mangkuk/mpasi_bulat','Mangkuk::mpasi_bulat');
$routes->get('Mangkuk/mpasi_kotak','Mangkuk::mpasi_kotak');
$routes->get('Mangkuk/penghalus','Mangkuk::penghalus');
$routes->get('Mangkuk/penghalus_polulu','Mangkuk::penghalus_polulu');
$routes->get('Mangkuk/mangkuk_silikon','Mangkuk::mangkuk_silikon');
$routes->get('Mangkuk/mangkuk_daun','Mangkuk::mangkuk_daun');
$routes->get('Mangkuk/mangkuk_dino','Mangkuk::mangkuk_dino');
$routes->get('Mangkuk/mangkuk_jupp','Mangkuk::mangkuk_jupp');
$routes->get('Mangkuk/mangkuk_mahkota','Mangkuk::mangkuk_mahkota');
$routes->get('Mangkuk/mangkuk_mahkota2','Mangkuk::mangkuk_mahkota2');
$routes->get('Mangkuk/mangkuk_MGBaby','Mangkuk::mangkuk_MGBaby');
$routes->get('Mangkuk/mangkuk_PoluluSS','Mangkuk::mangkuk_PoluluSS');
$routes->get('Mangkuk/mangkuk_Turku','Mangkuk::mangkuk_Turku');
$routes->get('Mangkuk/mangkuk_Turku_Double_Handle','Mangkuk::mangkuk_Turku_Double_Handle');
$routes->get('Mangkuk/mangkuk_Susu','Mangkuk::mangkuk_Susu');
$routes->get('Mangkuk/mangkuk_Susu_Single_Handle','Mangkuk::mangkuk_Susu_Single_Handle');
$routes->get('Mangkuk/turku_penghangat','Mangkuk::turku_penghangat');



$routes->get('Dot','Dot::index');
$routes->get('Dot/dot_beruang','Dot::dot_beruang');
$routes->get('Dot/dot_bulat','Dot::dot_bulat');
$routes->get('Dot/dot_rantai','Dot::dot_rantai');
$routes->get('Dot/dot_segitiga','Dot::dot_segitiga');
$routes->get('Dot/dot_buah','Dot::dot_buah');


$routes->get('Piring','Piring::index');
$routes->get('Piring/Piring_Astronot','Piring::Piring_Astronot');
$routes->get('Piring/Piring_beruang','Piring::Piring_beruang');
$routes->get('Piring/Piring_kepiting','Piring::Piring_kepiting');
$routes->get('Piring/Piring_kucing','Piring::Piring_kucing');
$routes->get('Piring/Piring_lebah','Piring::Piring_lebah');
$routes->get('Piring/Piring_monyet','Piring::Piring_monyet');
$routes->get('Piring/Piring_Oneset','Piring::Piring_Oneset');
$routes->get('Piring/Piring_Tertawa','Piring::Piring_Tertawa');
$routes->get('Piring/Piring_Tertawa_Kuping','Piring::Piring_Tertawa_Kuping');


$routes->get('Botol','Botol::index');
$routes->get('Botol/B_beruang','Botol::B_beruang');
$routes->get('Botol/kartun','Botol::kartun');
$routes->get('Botol/chaojun','Botol::chaojun');
$routes->get('Botol/classic','Botol::classic');
$routes->get('Botol/haojun','Botol::haojun'); 
$routes->get('Botol/kartun_gagang','Botol::kartun_gagang');
$routes->get('Botol/lucu','Botol::lucu');
$routes->get('Botol/botol700ml','Botol::botol700ml');
$routes->get('Botol/polulu240','Botol::polulu240');
$routes->get('Botol/botol_polulu','Botol::botol_polulu');
$routes->get('Botol/botol_sapi','Botol::botol_sapi');
$routes->get('Botol/botol_stiker','Botol::botol_stiker');
$routes->get('Botol/botol_stiker400','Botol::botol_stiker400');
$routes->get('Botol/botol_bebek','Botol::botol_bebek');
$routes->get('Botol/botol_kentangxi','Botol::botol_kentangxi');
$routes->get('Botol/botol_xintiger','Botol::botol_xintiger');
 
 
$routes->get('Gelas','Gelas::index');
$routes->get('Gelas/gelas_hisap','Gelas::gelas_hisap');
$routes->get('Gelas/gelas_kentang','Gelas::gelas_kentang');
$routes->get('Gelas/gelas_kopi','Gelas::gelas_kopi');
$routes->get('Gelas/gelas_miring','Gelas::gelas_miring');
$routes->get('Gelas/gelas_piala','Gelas::gelas_piala');
$routes->get('Gelas/gelas_piala_terbaru','Gelas::gelas_piala_terbaru');
$routes->get('Gelas/gelas_takar','Gelas::gelas_takar');
$routes->get('Gelas/gelas_karakter','Gelas::gelas_karakter');
$routes->get('Gelas/gelas_karakter_polulu','Gelas::gelas_karakter_polulu');
 
 

$routes->get('LunchBox','LunchBox::index');
$routes->get('LunchBox/lunch500','LunchBox::lunch500'); 
$routes->get('LunchBox/lunch800','LunchBox::lunch800');
$routes->get('LunchBox/lunch1400','LunchBox::lunch1400');
$routes->get('LunchBox/MPASI_dua_gagang','LunchBox::MPASI_dua_gagang');
$routes->get('LunchBox/MPASI_PP','LunchBox::MPASI_PP');
$routes->get('LunchBox/paus','LunchBox::paus');

  


$routes->get('Aksesoris','Aksesoris::index');
$routes->get('Aksesoris/baskom','Aksesoris::baskom');
$routes->get('Aksesoris/nail_care_set_duck','Aksesoris::nail_care_set_duck');
$routes->get('Aksesoris/Pegangan_Sendok_Kelinci','Aksesoris::Pegangan_Sendok_Kelinci');
$routes->get('Aksesoris/Pegangan_Sendok','Aksesoris::Pegangan_Sendok');


$routes->get('Dashboard','Dashboard::index');
$routes->get('BankData','BankData::index'); 


$routes->get('tambah_data', 'tambah_data::index');
 


$routes->get('Item', 'Item::index');
$routes->add('Item/save', 'Item::save'); 
$routes->get('Item/Create', 'Item::Create');
$routes->get('Item/preview/(:num)', 'Item::preview/$1');
$routes->get('Item/update_item/(:num)', 'Item::update_item/$1');
$routes->add('Item/update/(:num)', 'Item::update/$1');
$routes->delete('Item/(:num)', 'Item::delete/$1');




$routes->get('kategori', 'kategori::index');
$routes->add('Kategori/save', 'Kategori::save');
$routes->post('/kategori/update/(:num)', 'Kategori::update/$1');
 
$routes->get('Registrasi', 'Registrasi::index');
$routes->add('Registrasi/save', 'Registrasi::save');
$routes->get('Registrasi/edit/(:num)', 'Registrasi::edit/$1');
$routes->add('Registrasi/update/(:num)', 'Registrasi::update/$1');

 

$routes->get('Login', 'Login::index');
$routes->post('Login/access', 'Login::access');
$routes->get('Login/logout', 'Login::logout');

$routes->get('/restricted', 'Blocked::restricted');

