<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\Services;

class RoleCheck implements FilterInterface
{

   public function before(RequestInterface $request, $arguments = null)
   {
        $session = session();
        $role_id = $session->get('role_id');

        // Dapatkan nama controller yang sedang diakses
        $path = $request->getUri()->getPath();
        $segments = explode('/', $path);
        $controller = $segments[0] ?? '';

        // Definisikan akses yang diizinkan berdasarkan role_id
        $allowedAccess = $this->getAllowedAccess($role_id);

        // Periksa apakah controller termasuk dalam akses yang diizinkan
        if (!in_array($controller, $allowedAccess)) {
            return redirect()->to('/restricted')->with('error', 'Access Denied!');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada yang perlu dilakukan setelah request
    }
 
    private function getAllowedAccess($role_id)
    {
        $access = [
            1 => ['Dashboard', 'Item', 'BankData', 'Kategori', 'Registrasi'], // Admin
            2 => ['Dashboard', 'Item', 'BankData', 'Kategori'], // Editor
            3 => ['Leader'], // Leader
            4 => ['Telemarketing'], // Telemarketing
            5 => ['Customer'], // Customer
        ];

        return $access[$role_id] ?? [];
    }
}
