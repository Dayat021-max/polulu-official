<?php 
namespace App\Models;  
   
use CodeIgniter\Model;   

class UserModels extends Model
{
    protected $table = 'user';  
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['nama','slug','username','password','image','is_active', 'role_id','id_status'];
    protected $useAutoIncrement = true;
    /*protected $createdField = 'create_at';
    protected $updatedField = 'update_at';*/     
}
 