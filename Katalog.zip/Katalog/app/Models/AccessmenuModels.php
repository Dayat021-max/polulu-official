<?php 
namespace App\Models;  
   
use CodeIgniter\Model;   

class AccessmenuModels extends Model
{
    protected $table = 'user_access_menu';  
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['role_id','menu_id'];
    protected $useAutoIncrement = true;   
}
 