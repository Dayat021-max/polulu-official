<?php
namespace App\Models;  
  
use CodeIgniter\Model;  

class StatusModels extends Model
{
    protected $table = 'status'; 
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['kondisi'];
    protected $useAutoIncrement = true;
    /*protected $createdField = 'create_at';
    protected $updatedField = 'update_at';*/


    
}
