<?php 

namespace App\Models;  
 
use CodeIgniter\Model;  

class KategoriModels extends Model
{
    protected $table = 'kategori';
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['kategori','slug','img', 'id_user'];
    protected $useAutoIncrement = true;
    /*protected $createdField = 'create_at';
    protected $updatedField = 'update_at';*/
    

    public function getCount()
    {
        return $this->countAllResults();
    }
}

