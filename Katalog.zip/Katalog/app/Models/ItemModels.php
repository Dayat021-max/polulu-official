<?php 

namespace App\Models;  
   
use CodeIgniter\Model; 

class ItemModels extends Model
{ 
    protected $table = 'item'; 
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = [
    	'produk',
    	'slug',
    	'id_kategori', 
    	'harga_eceran',
    	'barcode',
    	'harga_grosir1',
    	'harga_grosir2',
    	'harga_grosir3',
    	'id_user',
    	'judul',
    	'foto1',
    	'foto2',
    	'foto3',
    	'foto4',
    	'foto5',
    	'foto6',
    	'foto7',
    	'foto8',
    	'foto9',
    	'produk_model',
    	'produk_size',
    	'produk_material',
    	'produk_kapasitas',
    	'produk_warna',
    	'keterangan',
        ];
    protected $useAutoIncrement = true;
    protected $createdField = 'create_at';
    protected $updatedField = 'updated_at';

    public function getCount()
    {
        return $this->countAllResults();
    }
}
