<?php
namespace App\Models; 

use CodeIgniter\Model;  

class RoleModels extends Model
{
    protected $table = 'user_role';
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['role_id','slug'];
    protected $useAutoIncrement = true;
    /*protected $createdField = 'create_at';
    protected $updatedField = 'update_at';*/ 
}
