<?php 
namespace App\Models;  
   
use CodeIgniter\Model;   

class SubmenuModels extends Model
{
    protected $table = 'user_sub_menu';  
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['menu_id','title','url','icon','is_active'];
    protected $useAutoIncrement = true;   
}
 