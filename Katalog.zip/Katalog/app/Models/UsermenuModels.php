<?php 
namespace App\Models;  
   
use CodeIgniter\Model;   

class UsermenuModels extends Model
{
    protected $table = 'user_sub_menu';  
    protected $primary_keys = 'id';
    protected $useTimestamps = true;
    protected $allowedFields = ['menu'];
    protected $useAutoIncrement = true;   
}
 