<header id="header" class="header fixed-top d-flex align-items-center">

<!-- Icon Sidebar -->
  <div class="d-flex align-items-center justify-content-between">
    <a href="<?= base_url('Dashboard'); ?>" class="logo d-flex align-items-center text-decoration-none" >
      <img src="<?= base_url('assets/img/logo1.svg'); ?>" alt="" >
      <span class="d-none d-lg-block " >Polulu Official</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
  </div>
<!-- Icon Sidebar -->
 
<!-- Navbar --> 
<nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">
        <!-- <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li> --><!-- End Search Icon-->

        <div class="dropdown pe-3">
          <button class="btn dropdown-toggle nav-link nav-profile d-flex align-items-center pe-0" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img src="<?= base_url('assets/img/user/'.$user['image']) ?>" alt="Profile" class="rounded-circle" width="100%" >
            <span class="d-none d-md-block ps-2" ><?= $user['nama'] ?></span>
          </button>
          <div >
            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile" aria-labelledby="dropdownMenu2">
              <li class="dropdown-header">
                <h6><?= $user['nama'] ?></h6>
                <span>
                  <?= $role_id['role_id'] ?>
                </span>
              </li>
              <li>
                <hr class="dropdown-divider">
              </li>
 
            <!-- My Profile -->
            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>
            <!-- End Profile -->

            <!-- Log Out -->
            <li>
              <a class="dropdown-item d-flex align-items-center" href="<?= base_url('Login/logout') ?>">
                <i class="bi bi-box-arrow-right"></i>
                <span>Log Out</span>
              </a>
            </li>
            <!-- End Log Out -->
            </ul>
            <!-- <button class="dropdown-item" type="button">Action</button>
            <button class="dropdown-item" type="button">Another action</button>
            <button class="dropdown-item" type="button">Something else here</button> -->
          </div>
        </div>

      </ul>
    </nav><!-- End Icons Navigation -->
<!-- End Navbar -->
</header>
