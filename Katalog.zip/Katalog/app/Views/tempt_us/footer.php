</main>
  <!-- ======= Footer ======= -->
<!--   <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits"> -->
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      <!-- Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer> --> 

<!--   <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

  <!-- Vendor JS Files --> 
  <script src="<?php echo base_url('assets/vendor/apexcharts/apexcharts.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/chart.js/chart.umd.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/echarts/echarts.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/quill/quill.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/simple-datatables/simple-datatables.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/tinymce/tinymce.min.js');?>"></script>
  <script src="<?php echo base_url('assets/vendor/php-email-form/validate.js');?>"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

  <!-- Tautkan berkas JavaScript Bootstrap (Popper.js dan jQuery diperlukan untuk modal) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

  <!-- Data Tables --> 
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js" ></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">var table = new DataTable('#example');</script>

  <script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script>
  <script type="text/javascript" src="<?php echo base_url('assets/datatables/js/datatables.js');?>"></script>
  <script type="text/javascript" src="<?php echo base_url('assets/datatables/js/datatables.min.js');?>"></script>

  <script src="<?php echo base_url('assets/js/link.js');?>"></script>

  <!-- owl -->
  <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!-- Owl Carousel JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    
  <!-- end owl -->
  <!-- Carousel -->

  <!-- End Carousel -->

  <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
    });
  </script>

  <script>
  // Aktifkan tooltip Bootstrap 
  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();
  });
  </script>

  <script type="text/javascript">
    $('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})
  </script>
  <!-- contoh -->
  <script src="<?= base_url('assets/vendor/tinymce/tinymce.min.js') ?>"></script>
    
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!-- Sampul -->
<script type="text/javascript">
  Function previewImg()
  {
    const sampul = document.querySelector('#sampul');
    const sampulLabel = document.querySelector('.costom-file-label');
    const imgPreview = document.querySelector('.img-preview');

    sampulLabel.textContent = sampul.files[0].name;

    const fileSampul = new FileReader();
    fileSampul.readAsDataURL(sampul.files[0]);

    fileSampul.onload = function(e) {
      imgPreview.src = e.target.result;
    }
  } 
</script>
<!-- End Sampul -->
<!-- corousell script -->

<!-- script SweetAlert2 sudah dimuat -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
    // Cek apakah ada pesan notifikasi dari session
    <?php if (session()->has('message')) : ?>
        // Tampilkan notifikasi SweetAlert2
        Swal.fire({
            icon: 'success',
            title: 'Sukses!',
            text: '<?= session('message') ?>'
        });

        // Hapus pesan notifikasi dari session agar tidak tampil lagi
        <?php session()->remove('message'); ?>
    <?php endif; ?>
</script>
<!-- Alret Gagal -->
<script>
    // Cek apakah ada pesan notifikasi dari session
    <?php if (session()->has('errors')) : ?>
        // Tampilkan notifikasi SweetAlert2
        Swal.fire({ 
            icon: 'error',
            title: 'Gagal!',
            text: '<?= session()->getFlashdata('errors') ?>'
        });

        // Hapus pesan notifikasi dari session agar tidak tampil lagi
        <?php session()->remove('message'); ?>
    <?php endif; ?>
</script>
<!-- end Alret Gagal -->

<!-- Alret Delet -->
<script>
    document.addEventListener('DOMContentLoaded', function () 
    {
    const deleteButtons = document.querySelectorAll('.delete-btn');
    const csrfToken = '<?= csrf_token() ?>'; // Dapatkan token CSRF

    deleteButtons.forEach(button => {
        button.addEventListener('click', function () {
            const itemId = this.getAttribute('data-id');

            Swal.fire({
                title: "Are you sure?",
                text: "You won't be able to revert this!",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, delete it!"
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('/Item/' + itemId, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        }
                    })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: "Deleted!",
                                text: "Your file has been deleted.",
                                icon: "success"
                            }).then(() => {
                                // Menghapus baris tabel setelah berhasil dihapus
                                button.closest('tr').remove();
                            });
                        } else {
                            Swal.fire({
                                title: "Error!",
                                text: data.message || "There was an error deleting your file.",
                                icon: "error"
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: "Error!",
                            text: "There was an error deleting your file.",
                            icon: "error"
                        });
                    }); 
                }
            });
        });
    });
});
</script>
<!-- End Alret Delet -->
<!-- End Sweet Alert -->


<script> 
    function zoom(e) {
        var zoomer = e.currentTarget;
        var offsetX = e.offsetX ? e.offsetX : e.touches[0].pageX;
        var offsetY = e.offsetY ? e.offsetY : e.touches[0].pageY;
        var x = (offsetX / zoomer.offsetWidth) * 100;
        var y = (offsetY / zoomer.offsetHeight) * 100;
        zoomer.style.transformOrigin = x + '% ' + y + '%';
        zoomer.style.transform = 'scale(2)';
    }

    function changeImage(src) {
        var mainImage = document.getElementById('mainImage');
        mainImage.src = src;
        mainImage.style.transform = 'scale(1)'; // Reset zoom on image change
    }

    document.getElementById('mainImage').addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
</script>
<!-- end zoom gallery -->

<!-- Coba Preview Image -->

<!-- <script>
    document.querySelectorAll('.image-input').forEach((input, index) => {
            input.addEventListener('change', function(event) {
                const file = event.target.files[0];
                const previewId = 'preview' + (index + 1);
                const previewImg = document.getElementById(previewId);

                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        previewImg.src = e.target.result;
                    }
                    reader.readAsDataURL(file);
                } else { 
                    previewImg.src = 'assets/img/default.png'; 
                }
            });
        });
</script>   --> 
<!-- Coba Preview Image -->

<!-- Preview Data item -->

<!-- End Privew Data Item -->
<!-- Rupiah -->
<script>
    document.querySelectorAll('.rupiah').forEach(function(input) {
        input.addEventListener('keyup', function(e) {
            var value = this.value.replace(/[^,\d]/g, '').toString();
            var split = value.split(',');
            var sisa = split[0].length % 3;
            var rupiah = split[0].substr(0, sisa);
            var ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                var separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
            this.value = 'Rp ' + rupiah;

            // Update hidden input yang sesuai
            var hiddenInputId = this.id.replace('_display', '');
            document.getElementById(hiddenInputId).value = value.replace(/\./g, '').replace(',', '.');
        });
    });
</script>

<!-- Rupiah -->

<!-- image preview dkk -->
<script>
        const container = document.getElementById('thumbnailContainer');

        let isDown = false;
        let startX;
        let scrollLeft;

        container.addEventListener('mousedown', (e) => {
            isDown = true;
            container.classList.add('active');
            startX = e.pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
            container.style.cursor = 'grabbing';
        });

        container.addEventListener('mouseleave', () => {
            isDown = false;
            container.classList.remove('active');
            container.style.cursor = 'grab';
        });

        container.addEventListener('mouseup', () => {
            isDown = false;
            container.classList.remove('active');
            container.style.cursor = 'grab';
        });

        container.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - container.offsetLeft;
            const walk = (x - startX) * 3; // Jumlah scroll (lebih besar untuk scrolling lebih cepat)
            container.scrollLeft = scrollLeft - walk;
        });

        // Untuk perangkat mobile
        container.addEventListener('touchstart', (e) => {
            isDown = true;
            startX = e.touches[0].pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
        });

        container.addEventListener('touchend', () => {
            isDown = false;
        });

        container.addEventListener('touchmove', (e) => {
            if (!isDown) return;
            const x = e.touches[0].pageX - container.offsetLeft;
            const walk = (x - startX) * 3; // Jumlah scroll (lebih besar untuk scrolling lebih cepat)
            container.scrollLeft = scrollLeft - walk;
        });
</script>
<!-- end image preview dkk -->
</body>
</html> 