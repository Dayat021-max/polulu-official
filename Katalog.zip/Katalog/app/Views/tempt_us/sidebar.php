 <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="<?= base_url('Dashboard');?>">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span> 
        </a>
      </li>
      <!-- End Dashboard Nav -->
 
      <li class="nav-item"> 
        <a class="nav-link collapsed" href="<?= base_url('BankData');?>">
          <i class="bi bi-database-add"></i>  
          <span>Master Data</span>
        </a>
      </li>
       <!-- End Tambah data -->


      <li class="nav-heading">Pages</li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="users-profile.html">
          <i class="bi bi-person"></i>
          <span>Profile</span>
        </a>
      </li>
      
       <!-- End Profile Page Nav -->

       <?php 
        if ($akses == 1) {
            echo '
            <li class="nav-item">
                <a class="nav-link collapsed" href="'. base_url('Registrasi') .'">
                    <i class="bi bi-person"></i>
                    <span>Registrasi</span>
                </a>
            </li>
            ';
        }
        ?>

       <!-- End Registrasi Page Nav -->

      <li class="nav-item"> 
        <a class="nav-link collapsed" href="<?= base_url('Login/logout') ?>">
          <i class="bi bi-card-list"></i>
          <span>Logout</span>
        </a>
      </li>
      
       <!-- End Register Page Nav -->

  </aside><!-- End Sidebar-->