<!-- Kategori Produk -->  
<section class="bg-Light"> 
	<div class="container text-center">
		<!-- Head Kategori --> 
		<div class="text-center pt-5 pb-3">
			<h1 class="text-secondary font-weight-bold display-4"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="row">  
				<div class="col-lg-6 mb-5"> 
					<div class="col-12"> 
 
						<div class="image-container">
					        <img id="mainImage" src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/judul.jpg');?>" alt="Main Image" onmousemove="zoom(event)">
					    </div>
					    <div class="thumbnail-container">
					        <img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/judul.jpg');?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/judul.jpg');?>')" class="box_detail">
					        <img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/1.jpg');?>" alt="Thumbnail 2" onclick="changeImage('<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/1.jpg');?>')" class="box_detail">
					        <img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/2.jpg');?>" alt="Thumbnail 3" onclick="changeImage('<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/2.jpg');?>')" class="box_detail">
					        <img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/3.jpg');?>" alt="Thumbnail 3" onclick="changeImage('<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/3.jpg');?>')" class="box_detail">
					        <img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/4.jpg');?>" alt="Thumbnail 3" onclick="changeImage('<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/4.jpg');?>')" class="box_detail">
					    </div>
					        <!-- Add more gallery items as needed -->
						<!-- <div class="box_cover" >
							<img class="zoomImg" id="expandedImg" style="width:100%" src="<?= base_url('assets/img/produk/botol/haojun/judul.png') ?>"
							>
						</div> -->
					</div>
				</div>  

				<!-- Spesifikasi Produk -->
				<div class="col-lg-6  justify-content-center ">
					<div class="title_header">
						<h1 class="mb-4"><label> Spesifikasi Produk</label></h1>
					</div>
					<div class="deskripsi">
						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Model</label>
							 </div>
							 <div class="col text-left">
							 	<label>One Set</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Size</label>
							 </div>
							 <div class="col text-left">
							 	<label>18x4 cm</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Material</label>
							 </div>
							 <div class="col text-left">
							 	<label>PP + Silicon</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Kapasitas</label>
							 </div>
							 <div class="col text-left">
							 	<label>-</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Warna</label>
							 </div>
							 <div class="col text-left">
							 	<label>Kuning, Biru</label>
							 </div>
						</div>
					</div>
 
					<!-- contact us -->
					<div class="contact">
						<div class="title_header mt-3">
							<label class="mt-3 mb-0 font-weight-bold" >Harga Ecer</label>
							<div class="mb-4">
								<label class="m-0 display-5">Rp 14.500,-</label>
							</div>
							<label class="mt-3 mb-0 font-weight-bold" >Harga Grosir</label>

						<div class="d-flex justify-content-center">
							<label class="m-2">Rp 14.500,-</label>
							<label class="m-2">Rp 14.500,-</label>
							<label class="m-2">Rp 14.500,-</label>
							<!-- <label>Rp 14.500,-</label>
							<label>Rp 14.500,-</label>
							<h4 class="m-2">Rp 14.500,-</h4>
							<h4 class="m-2">Rp 14.500,-</h4>
							<h4 class="m-2">Rp 14.500,-</h4> -->
						</div>

						<h4>bisa dinego langsung</h4>
					</div>
					<div class="title_body mt-5">
						<h1>Segera hubungi :</h1>
						<div class="d-flex mt-3 ">
							<div class="row justify-content-center pl-5 pr-5">
								<a href=""  id="WAmita" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Mita</h3>
									 </div>
								 </a>

								 <a href="" id="WAayu" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ayu</h3>
									 </div>
								 </a>
							</div>
 
							<div class="row justify-content-center pl-5 pr-5">
								<a href="" id="WAersa" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ersa</h3>
									 </div>
								 </a>

								 <a href="" id="WAecha" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Echa</h3>
									 </div>
								 </a>
							</div>
						</div>
					</div>
					</div>
					<!-- end contact us -->
				</div>
				<!-- end spesifikasi produk -->
		</div> 
	</div>
</section>
<script>
	function myFunction(imgs) {
	  // Get the expanded image
	  var expandImg = document.getElementById("expandedImg");
	  // Get the image text
	  var imgText = document.getElementById("imgtext");
	  // Use the same src in the expanded image as the image being clicked on from the grid
	  expandImg.src = imgs.src;
	  // Use the value of the alt attribute of the clickable image as text inside the expanded image
	  imgText.innerHTML = imgs.alt;
	  // Show the container element (hidden with CSS)
	  expandImg.parentElement.style.display = "block";
}
</script>


<!-- End Kategori Produk --> 