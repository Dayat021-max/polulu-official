    <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $judul ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('Dashboard') ?>" class="text-decoration-none">Home</a></li>
          <li class="breadcrumb-item active"><?= $judul ?></li>
        </ol>
      </nav> 
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="col-lg-12">
          <div class="row justify-content-center">
            <!-- Kategori Card -->
                <div class="col-xxl-4 col-md-6">
                  <div class="card info-card sales-card">
                    <div class="card-body">
                      <h5 class="card-title" style="font-size: 30px; padding: 0;">Data Kategori <span>| Today</span></h5>
                      <div class="d-flex align-items-center justify-content-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                          <i class="bi bi-diagram-3-fill"></i>
                        </div>
                        <div class="ps-3">                      
                          <h6>145</h6>
                        </div>
                      </div>
                      <a href="<?= base_url('kategori')?>" class="btn btn-primary w-100 mt-3">
                        <i class="bi bi-layer-backward"></i> Open Data
                        </a>
                    </div>
                  </div>
                </div>
            <!-- End Kategori Card -->

            <!-- Kategori Card -->
                <div class="col-xxl-4 col-md-6">
                  <div class="card info-card sales-card">
                    <div class="card-body">
                      <h5 class="card-title" style="font-size: 30px; padding: 0;">Data Item <span>| Today</span></h5>
                      <div class="d-flex align-items-center justify-content-center">
                        <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                          <i class="bi bi-box-seam"></i>
                        </div>
                        <div class="ps-3">                      
                          <h6>145</h6>
                        </div>
                      </div>
                      <a href="<?= base_url('Item')?>" class="btn btn-primary w-100 mt-3">
                        <i class="bi bi-layer-backward"></i> Open Data
                        </a>
                    </div>
                  </div>
                </div>
            <!-- End Kategori Card -->
          </div>
      </div>
    </section> 

  </main><!-- End #main -->