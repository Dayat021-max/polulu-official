    <main id="main" class="main">

    <div class="pagetitle">  
      <h1><?= $judul ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('Dashboard') ?>" class="text-decoration-none">Home</a></li>
          <li class="breadcrumb-item active"><?= $judul ?></li>
        </ol>
      </nav> 
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="col-lg-12">
          <div class="row justify-content-center">
            <!-- Recent Sales -->
            <div class="col-lg-12">
          <div class="row">
            <!-- Recent Sales --> 
            <div class="col-12">
              <div class="card recent-sales overflow-auto"> 
                <div class="card-body">
                  <h5 class="card-title text-center ">Produk Tersedia <span>| Today</span>
                  </h5>
                  <div class="d-flex align-items-center justify-content-end">
                    <a class="btn btn-primary" type="button" href="<?= base_url('Item/Create') ?>">Tambah Data</a>
                  </div>
 
                  <!-- Table --> 
                  <div class="mt-3"> 
                    <table id="myTable" class="table table-striped table-hover">
                        <thead class="thead-light"> 
                            <tr> 
                                <th class="text-center">No</th> 
                                <th class="text-center">Nama Produk</th>
                                <th class="text-center">Barcode</th> 
                                <th class="text-center">Gambar</th>
                                <th class="text-center">Kategori</th> 
                                <th class="text-center">Tanggal Input</th>  <!-- Create At -->
                                <th class="text-center">User</th>
                                <th class="text-center">Tools</th>
                            </tr>
                        </thead>  
                        <tbody> 
                                <?php $no = 1; ?>
                                <?php foreach ($dat_item as $i ) :?> 
                            <tr class="text-center">    
                                <td><?= $no++; ?></td>
                                <td><?= $i['produk']; ?></td> 
                                <td><?= $i['barcode']; ?></td> 
                                <td> 
                                    <img src="<?= base_url('assets/img/item/'. $i['judul']) ?>"  class="rounded zoom" width="50" >
                                </td> 
                                <td>
                                  <?php foreach ($dat_kategori as $kat) : ?>
                                    <?php if($i['id_kategori'] == $kat['id'] ) : ?>
                                      <?= $kat['kategori']; ?>
                                    <?php endif;  ?>
                                  <?php endforeach; ?>
                                </td>
                                <td><?= $i['create_at']; ?></td>
                                <td><?php foreach ($users as $user) : ?>
                                      <?php if ($user['id'] == $i['id_user']) : ?>
                                          <?= $user['nama'] ?>
                                      <?php endif; ?>
                                  <?php endforeach; ?></td>                                <td>
                                  <button class="btn btn-danger delete-btn" data-id="<?= $i['id']; ?>">Delete</button>
                                  <a href="/Item/preview/<?= $i['id']; ?>" class="btn btn-primary">Lihat</a>
                                  <a href="/Item/update_item/<?= $i['id']; ?>" class="btn btn-success">edit</a>
                                </td>

                                <?php endforeach; ?>
                            </tr>
                        </tbody>
                    </table>
                  <!-- End Table -->
                  </div>
 


                </div>
              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div>
            <!-- End Recent Sales -->
          </div>
      </div>
    </section> 



  </main><!-- End #main -->