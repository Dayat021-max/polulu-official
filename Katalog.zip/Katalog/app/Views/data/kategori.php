    <main id="main" class="main">

    <div class="pagetitle">
      <h1>Kategori</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('/Dashboard'); ?>">Home</a></li>
          <li class="breadcrumb-item active">Kategori</li> 
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row justify-content-center">
        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">
            <!-- Recent Sales --> 
            <div class="col-12">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title text-center ">Kategori<span>| Today</span>
                  </h5>
                  <div class="d-flex align-items-center justify-content-end">
                    <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#staticBackdrop">Tambah Data</button>
                  </div> 

                  <!-- Notification Validation -->
                   
                  <!-- End Notification --> 

 
                  <!-- Table -->
                  <div class="mt-3">

                    <table id="myTable" class="display">
                        <thead>
                            <tr> 
                                <th>No</th>
                                <th>Nama Kategori</th>
                                <th>Image</th>
                                <th>Tanggal Input</th>
                                <th>User</th>
                                <th>Tools</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $no = 1; ?>
                          <?php foreach($Kategori as $Kat ) : ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $Kat['kategori']; ?></td>
                                <td>
                                   
                                    <img src="<?= base_url('assets/img/kategori/' . $Kat['img']) ?>" width="100" class="zoom rounded" >
                                  </td>
                                <td><?= $Kat['created_at']; ?></td>
                                <td>
                                  <?php foreach ($users as $user) : ?>
                                      <?php if ($user['id'] == $Kat['id_user']) : ?>
                                          <?= $user['nama'] ?>
                                      <?php endif; ?>
                                  <?php endforeach; ?>

                                </td>
                                <td>
                                  <a href="/Kategori/edit/<?= $Kat['slug']; ?>" class="btn btn-primary" type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?= $Kat['id']; ?>">Edit</a>
                                </td>
                            </tr>
                          <?php endforeach; ?>
                        </tbody>
                    </table>
                  <!-- End Table -->
                  </div>



                </div>
              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->
      
      </div>
    </section> 


<!-- Modal Tambah Kategori-->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div> 
      <div class="modal-body"> 
       <form action="Kategori/save" method="post" enctype="multipart/form-data">
        <?= csrf_field(); ?>
        <!-- Nama Produk --> 
         <div class="form-group">
          <label for="exampleInputEmail1">Nama Kategori</label>
          <input type="text" class="form-control" id="kategori" aria-describedby="kategori" name="kategori" autofocus required>
          <input type="hidden" class="form-control" id="user" value="<?= $nama['id'] ?>" name="user" >
          <small id="kategori" class="form-text text-muted">Tidak Boleh Kosong.</small>
        </div>
          <div class="card">
            <img src="<?= base_url('assets/img/kategori/default.png') ?>" id="preview1" class="card-img-top" alt="Image preview" style="max-width: 100%;">
            <div class="card-body">
              <input type="file" id="image1" class="image-input form-control" accept="image/*" name="kategori_foto" required>
            </div>
          </div>
        <!-- end nama produk -->

       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      </form>
    </div>
  </div>
</div> 


<!-- Modal Edit Katalog-->
<!-- Modal -->
<?php foreach($Kategori as $dat_kategori) { ?>
<div class="modal fade" id="editModal<?= $dat_kategori['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Kategori</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?= csrf_field(); ?>
        <form action="<?= base_url('kategori/update/'.$dat_kategori['id']) ?>" method="post" enctype="multipart/form-data">
          <!-- Nama Kategori -->
          <div class="form-group">
            <label for="kategori">Nama Kategori</label>
            <input type="text" class="form-control" id="kategori" name="kategori" autofocus value="<?= $dat_kategori['kategori'] ?>">
            <input type="hidden" class="form-control" id="user" value="<?= $nama['id']; ?>" name="user" >
            <small id="kategoriHelp" class="form-text text-muted">Tidak Boleh Kosong.</small>
          </div>

          <div class="card mt-3">
            <img src="<?= base_url('assets/img/kategori/' . $dat_kategori['img']) ?>" id="preview<?= $dat_kategori['id'] ?>" class="card-img-top" alt="Image preview" style="max-width: 100%;">
            <div class="card-body">
              <input type="file" id="image<?= $dat_kategori['id'] ?>" class="image-input form-control" accept="image/*" name="kategori_foto">
            </div>
          </div>
          <!-- end nama kategori -->
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div> 
</div>
<script>
document.getElementById('image<?= $dat_kategori['id'] ?>').addEventListener('change', function(event) {
    const file = event.target.files[0];
    const preview = document.getElementById('preview<?= $dat_kategori['id'] ?>');

    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
        }
        reader.readAsDataURL(file);
    }
});
</script>
<?php } ?>


  </main><!-- End #main -->