    <main id="main" class="main">

    <div class="pagetitle">
      <h1>Tambah Data</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('/Dashboard'); ?>">Home</a></li>
          <li class="breadcrumb-item active">Tambah Data</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row justify-content-center">
        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">
            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title text-center ">Produk Tersedia <span>| Today</span>
                  </h5>
                  <div class="d-flex align-items-center justify-content-end">
                    <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#staticBackdrop">Tambah Data</button>
                  </div>

                  <!-- Table -->
                  <div class="mt-3">
                    <table id="myTable" class="display">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Produk</th>
                                <th>Kategori</th>
                                <th>Tanggal Input</th>
                                <th>User</th>
                                <th>Tools</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Row 1 Data 1</td>
                                <td>Row 1 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>
                                  <a href="" class="btn btn-warning">Hapus</a>
                                  <a href="" class="btn btn-primary">Edit</a>
                                </td>
                            </tr>
                            <tr>
                                <td>Row 2 Data 1</td>
                                <td>Row 2 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>Row 1 Data 2</td>
                                <td>
                                  <a href="" class="btn btn-warning">Hapus</a>
                                  <a href="" class="btn btn-primary">Edit</a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                  <!-- End Table -->
                  </div>



                </div>
              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->
      
      </div>
    </section>


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form>
        <!-- Nama Produk -->
         <div class="form-group">
          <label for="exampleInputEmail1">Nama Produk</label>
          <input type="name_produk" class="form-control" id="name_produk" aria-describedby="name_produk">
          <small id="name_produk" class="form-text text-muted">Tidak Boleh Kosong.</small>
        </div>
        <!-- end nama produk -->

        <!-- Jenis Produk -->
        <div class="form-group">
          <label for="inputState">Kategori</label>
          <select id="inputState" class="form-control">
            <option selected>Pilih Kategori Produk</option>
            <option>...</option>
          </select>
        </div>
        <!-- End Jenis Produk -->

        <!-- upload foto produk -->

        <!-- foto 1 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Foto Display</label>
          </div>
        </div>
        <!-- End Foto 1 -->

        <!-- foto 2 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 2 -->

        <!-- foto 3 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 3 -->

        <!-- foto 4 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 4 -->

        <!-- foto 5 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 5 -->

        <!-- foto 6 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 6 -->

        <!-- foto 7 -->
        <div class="input-group mb-3">
          <div class="custom-file">
            <input type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
            <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
          </div>
        </div>
        <!-- End Foto 7 -->



        <!-- end foto produk -->
       </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Understood</button>
      </div>
    </div>
  </div>
</div>

  </main><!-- End #main -->