 <!-- Deskripsi produk -->
 <section class="bg-light ">
 	<div class="container text-center ">
 		<!-- Head Produk -->
 		<div class=" text-center pt-5 pb-5">
 			<h1 class="text-secondary font-weight-bold" >Produk <?= $kategori['kategori'] ?></h1>
 		</div>
 		<!-- Body Produk -->
 		<div class="container mb-5">
 			<div class="col-lg-12 d-flex flex-wrap justify-content-center p-0 ">
 				<?php foreach ($items as $i) : ?>
 				<a href="/Landpage/view/<?= $i['id']; ?>" class="text-decoration-none">
 					<div class="box hover">
 						<img src="<?= base_url('assets/img/item/'. $i['judul']) ?>" >
 						<div class="box-image">
 							
 						</div>
 						<div>
 							<span class="text-secondary"><?= $i['produk'] ?></span>
 						</div>
 					</div> 
 				</a>
 				<?php endforeach; ?>
 			</div>
 		</div>
 		<!-- End Body Produk -->
 	</div>
 </section>
 <!-- End Deskripsi produk -->