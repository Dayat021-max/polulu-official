 <!-- Kategori Produk -->
<section class="bg-Light"> 
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="row"> 
				<div class="col-lg-6">
					<div class="col-12">
						<div class="box_cover">

							<img class="zoomImg" id="expandedImg" style="width:100%" src="<?= base_url('assets/img/produk/dot/dot_bulat/judul.png') ?>">
						</div>
					</div>
				</div> 
				<div class="col-lg-6 d-flex flex-wrap justify-content-center">
					<a href="#" class="text-decoration-none">
						<div class="box_detail">
							<img src="<?= base_url('assets/img/produk/dot/dot_bulat/judul.png') ?>" style="
							height: 180px;
						    width: 180px;
						    margin: auto;
						    border-radius: 10px;
						    margin-top: 10px;
						    margin-bottom: 10px;" alt="judul" onclick="myFunction(this);">
						</div>
					</a>

					<a href="#" class="text-decoration-none" >
						<div class="box_detail">
							<img src="<?= base_url('assets/img/produk/dot/dot_bulat/1.png') ?>" style="
							height: 180px;
						    width: 180px;
						    margin: auto;
						    border-radius: 10px;
						    margin-top: 10px;
						    margin-bottom: 10px;" alt="one" onclick="myFunction(this);">
						</div>
					</a>

					<a href="#" class="text-decoration-none" >
						<div class="box_detail">
							<img src="<?= base_url('assets/img/produk/dot/dot_bulat/2.png') ?>" style="
							height: 180px;
						    width: 180px;
						    margin: auto;
						    border-radius: 10px;
						    margin-top: 10px;
						    margin-bottom: 10px;" alt="two" onclick="myFunction(this);">
						</div>
					</a>

					<a href="#" class="text-decoration-none" >
						<div class="box_detail">
							<img src="<?= base_url('assets/img/produk/dot/dot_bulat/3.jpg') ?>" style="
							height: 180px;
						    width: 180px;
						    margin: auto;
						    border-radius: 10px;
						    margin-top: 10px;
						    margin-bottom: 10px;" alt="tree" onclick="myFunction(this);">
						</div>
					</a>
				</div>
				
			</div>

			<!-- Deskripsi barang -->
			<div class="row">
				<div class="col-lg-6">
					<div class="title_header">
						<h1 class="mb-4 mt-5">Spesifikasi Produk</h1>
					</div>
					<div class="deskripsi">
						<div class="row justify-content-center pl-5 pr-5">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Model</label>
							 </div>
							 <div class="col text-left">
							 	<label>One Set</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-5 pr-5">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Size</label>
							 </div>
							 <div class="col text-left">
							 	<label>18x4 cm</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-5 pr-5">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Material</label>
							 </div>
							 <div class="col text-left">
							 	<label>PP + Silicon</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-5 pr-5">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Kapasitas</label>
							 </div>
							 <div class="col text-left">
							 	<label>-</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-5 pr-5">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Warna</label>
							 </div>
							 <div class="col text-left">
							 	<label>Kuning, Biru</label>
							 </div>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="title_header">
						<h4 class="mt-5 mb-0">
							<label class="m-0" >Harga</label>
						</h4>
						<h1 class="mb-4">Rp 14.500,-</h1>
					</div>
					<div class="title_body">
						<h1>Segera hubungi :</h1>
						<div class="d-flex mt-3 ">
							<div class="row justify-content-center pl-5 pr-5">
								<a href=""  id="WAmita" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Mita</h3>
									 </div>
								 </a>

								 <a href="" id="WAayu" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ayu</h3>
									 </div>
								 </a>
							</div>

							<div class="row justify-content-center pl-5 pr-5">
								<a href="" id="WAersa" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ersa</h3>
									 </div>
								 </a>

								 <a href="" id="WAecha" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Echa</h3>
									 </div>
								 </a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div> 
	</div>
</section>
<script>
	function myFunction(imgs) {
	  // Get the expanded image
	  var expandImg = document.getElementById("expandedImg");
	  // Get the image text
	  var imgText = document.getElementById("imgtext");
	  // Use the same src in the expanded image as the image being clicked on from the grid
	  expandImg.src = imgs.src;
	  // Use the value of the alt attribute of the clickable image as text inside the expanded image
	  imgText.innerHTML = imgs.alt;
	  // Show the container element (hidden with CSS)
	  expandImg.parentElement.style.display = "block";
}
</script>
<!-- End Kategori Produk -->