<!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori --> 
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold">Produk Piring Makan</h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">

				<a href="Piring/Piring_Astronot">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/astronot/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">Piring Astronot</span>
					</div>
				</div>


				<a href="Piring/Piring_beruang">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/beruang/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
						<div>
							<span class="text-secondary">Piring Beruang Silikon</span>
						</div>
					</div> 
				

				<a href="Piring/Piring_kepiting">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/kepiting/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
						<div>
							<span class="text-secondary">Piring Kepiting Silikon</span>
						</div>
					</div>

				<a href="Piring/Piring_kucing">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/kucing/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
						<div>
							<span class="text-secondary">Piring Kucing Silikon</span>
						</div>
					</div>

				<a href="Piring/Piring_lebah">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/lebah/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
					<div>
						<span class="text-secondary">Piring Lebah</span>
					</div>
				</div>

				<a href="Piring/Piring_monyet">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/monyet/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
					<div>
						<span class="text-secondary">Piring Monyet</span>
					</div>
				</div>

				<a href="Piring/Piring_Oneset">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/oneset/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
					<div>
						<span class="text-secondary">Piring Silikon Set</span>
					</div>
				</div>

				<a href="Piring/Piring_Tertawa">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/ketawa/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Piring/Piring_Tertawa_Kuping">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/piring/tertawa_gagang/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
				</a>
					<div>
						<span class="text-secondary">Piring Tertawa Kuping</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->