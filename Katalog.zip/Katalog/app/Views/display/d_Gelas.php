<!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">
				<a href="Gelas/gelas_hisap">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/gelas_hisap/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Hisap</span>
					</div>
				</div>

				<a href="Gelas/gelas_kentang">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/kentang/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Kentang</span>
					</div>
				</div>

				<a href="Gelas/gelas_kopi">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/kopi/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Kopi</span>
					</div>
				</div>

				<a href="Gelas/gelas_miring">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/miring/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Kopi</span>
					</div>
				</div>

				<a href="Gelas/gelas_piala">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/piala/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Piala</span>
					</div>
				</div>

				<a href="Gelas/gelas_piala_terbaru">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/piala2/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Piala Terbaru</span>
					</div>
				</div>

				<a href="Gelas/gelas_takar">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/takar/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Takar Obat Bayi</span>
					</div>
				</div>

				<a href="Gelas/gelas_karakter">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/gelas/mug_kartun/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Karakter</span>
					</div>
				</div>

				<a href="Gelas/gelas_karakter_polulu">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/gelas/mug_polulu/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Gelas Karakter Polulu</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->