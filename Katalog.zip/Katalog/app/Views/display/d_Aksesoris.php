<!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">

				<a href="Aksesoris/baskom">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/aksesoris/baskom/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Baskom Lipat</span>
					</div>
				</div>

				<a href="Aksesoris/nail_care_set_duck">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/aksesoris/nail/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Nail Care Set Duck</span>
					</div>
				</div>

				<a href="Aksesoris/Pegangan_Sendok_Kelinci">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/aksesoris/sendok_kelinci/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Pegangan Sendok Kelinci</span>
					</div>
				</div>

				<a href="Aksesoris/Pegangan_Sendok">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/aksesoris/pegangan_Sendok/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Pegangan Sendok</span>
					</div>
				</div>

				<a href="LunchBox/MPASI_PP">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/pp/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal MPASI PP</span>
					</div>
				</div>

				<a href="LunchBox/paus">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/paus/judul.webp');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal Paus</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div> 
</section>

<!-- End Kategori Produk -->