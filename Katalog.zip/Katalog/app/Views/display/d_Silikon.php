 <!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold">Produk Silikon</h1>
		</div> 
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">
				<a href="Silikon/xin">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/Sendok _Xin_Tiger/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Silikon/polulu_merah">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/polulu_sendok/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Polulu</span>
					</div>
				</div>

				<a href="Silikon/Sendok_Turku">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/sendok_turku/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Turku</span>
					</div>
				</div>

				<a href="Silikon/sendok_kotak">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/sendok_kotak/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Kotak</span>
					</div>
				</div>

				<a href="Silikon/dual_varian">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/dual_varian/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Kotak</span>
					</div>
				</div>

				<!-- coba flex -->
				<a href="Silikon/xin_love">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/xin_love/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Kotak</span>
					</div>
				</div>

				<a href="Silikon/sendok_pinguin">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/sendok_pinguin/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Kotak</span>
					</div>
				</div>

				<a href="Silikon/sendok_judo">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/silikon/sendok_judo/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sendok Kotak</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->