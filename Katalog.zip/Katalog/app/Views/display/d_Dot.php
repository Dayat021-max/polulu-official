  <!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center"> 

				<a href="Dot/dot_beruang">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/dot/dot_beruang/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Dot/dot_bulat">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/dot/dot_bulat/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Dot/dot_rantai">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/dot/empeng_rantai/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>


				<a href="Dot/dot_segitiga">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/dot/empeng_segitiga/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Dot/dot_buah">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/dot/dot_buah/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a> 
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->