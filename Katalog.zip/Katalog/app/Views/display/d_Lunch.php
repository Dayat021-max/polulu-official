<!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">

				<a href="LunchBox/lunch500">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/500/1.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal 500 Mili</span>
					</div>
				</div>

				<a href="LunchBox/lunch800">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/800/1.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal 800 Mili</span>
					</div>
				</div>

				<a href="LunchBox/lunch1400">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/1400/1.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal 1400 Mili</span>
					</div>
				</div>

				<a href="LunchBox/MPASI_dua_gagang">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/duagagang/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal MPASI Dua Gagang</span>
					</div>
				</div>

				<a href="LunchBox/MPASI_PP">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/pp/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal MPASI PP</span>
					</div>
				</div>

				<a href="LunchBox/paus">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/lunch/paus/judul.webp');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Kotak Bekal Paus</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div> 
</section>

<!-- End Kategori Produk -->