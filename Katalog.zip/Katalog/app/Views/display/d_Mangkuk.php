 <!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori --> 
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold"><?= $judul ?></h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">

				<a href="Mangkuk/mpasipp">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mpasipp/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk MPASIPP</span>
					</div>
				</div>


				<a href="Mangkuk/mpasi_beruang">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mpasi_beruang/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk MPASIPP</span>
					</div>
				</div>
				

				<a href="Mangkuk/mpasi_bulat">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mpasi_bulat/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk MPASI Bulat</span>
					</div>
				</div>

				<a href="Mangkuk/mpasi_kotak">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mpasi_kotak/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk MPASI KOTAK</span>
					</div>
				</div>

				<a href="Mangkuk/penghalus">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/penghalus/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Penghalus</span>
					</div>
				</div>

				<a href="Mangkuk/penghalus_polulu">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/penghalus_polulu/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Penghalus Polulu</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_silikon">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_silikon/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Silikon</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_daun">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/daun/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Daun</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_dino">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/dino/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Dino</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_jupp">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/jupp/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Jupp</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_mahkota">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mahkota/judul.webp');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Mahkota</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_mahkota2">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mahkota_2/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Mahkota 2</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_MGBaby">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/MGBaby/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk MGBaby</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_PoluluSS">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/poluluSS/5.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Polulu Stainless Steel</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_Turku">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/turku1/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Isolasi Air</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_Turku_Double_Handle">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/turku_double/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Tahan Karat</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_Susu">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/mangkuk_susu/1.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Tahan Karat</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_Susu_Single_Handle">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/susu_2/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Tahan Karat</span>
					</div>
				</div>

				<a href="Mangkuk/mangkuk_Susu_Single_Handle">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/turku2/judul.jpg');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Dual Handgrip</span>
					</div>
				</div>

				<a href="Mangkuk/turku_penghangat">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/mangkuk/turku3/judul.png');?>">
						<div class="box-image">
							 
						</div> 
				</a> 
					<div>
						<span class="text-secondary">Mangkuk Turku Penghangat</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->