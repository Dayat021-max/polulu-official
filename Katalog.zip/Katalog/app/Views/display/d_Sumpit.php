 <!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold">Produk Sumpit</h1>
		</div> 
		<!-- Body Kategori --> 
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">
				<a href="Sumpit/polulu_ho">
					<div class="box hover">
						<img src="<?= base_url('assets/img/produk/sumpit/polulu_ho/judul.png');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							 
						</div>
				</a>
					<div>
						<span class="text-secondary">Sumpit Polulu Helm Oranye</span>
					</div>
				</div>
				<a href="Sumpit/polulu_hb">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/polulu_hb/judul.png');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
			
				<a href="Sumpit/polulu_bear">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/polulu_bear/judul.jpg');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Sumpit/bean">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/bean/judul.jpg');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Sumpit/polulu_tiger">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/polulu_tiger/judul.png');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Sumpit/polulu_koala">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/koala/judul.png');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<a href="Sumpit/Gduck">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/duckbiru/judul.png');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<a href="Sumpit/Buaya">
				<div class="box hover">
					<img src="<?= base_url('assets/img/produk/sumpit/buaya/judul.jpg');?>" style="
					height: 180px;
				    width: 180px;
				    margin: auto;
				    border-radius: 10px;
				    margin-top: 10px;
				    margin-bottom: 10px;">
					<div class="box-image">
						
					</div>
				</a>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->