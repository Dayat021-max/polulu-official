<!-- Kategori Produk -->
<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5"> 
			<h1 class="text-secondary font-weight-bold">Produk Botol Bayi</h1>
		</div>  
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center p-0">
 
				<a href="Botol/B_beruang" class="text-decoration-none">
					<div class="box hover"> 

						<img src="<?= base_url('assets/img/produk/botol/beruang/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Beruang</span>
						</div>
					</div>
				</a>

				<a href="Botol/kartun" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/kartun/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Kartun</span>
						</div>
					</div>
				</a>

				<a href="Botol/chaojun" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/chaojun/judul.png');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Chaojun</span>
						</div>
					</div>
				</a>

				<a href="Botol/classic" class="text-decoration-none">
					<div class="box hover">  
						<img src="<?= base_url('assets/img/produk/botol/classic/judul.png');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Classic</span>
						</div>
					</div>
				</a>

				<a href="Botol/haojun" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/haojun/judul.png');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Haojun</span>
						</div>
					</div>
				</a>

				<a href="Botol/kartun_gagang" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/kartun_gagang/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Kartun handle</span>
						</div>
					</div>
				</a>
 
				<a href="Botol/lucu" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/lucu/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Lucu</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol700ml" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/700ml/judul.png');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Minum 700mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/polulu240" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/kentang240/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Kentang 240mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_polulu" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/botol_polulu/judul.jpg');?>">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Polulu 240mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_sapi" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/sapi/judul.jpg');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Sapi 240mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_stiker" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/stiker/judul.jpg');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Stiker 500 mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_stiker400" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/stiker400/judul.png');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Stiker 400 mili</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_bebek" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/bebek/judul.jpg');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Karakter Bebek</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_kentangxi" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/kentangxintiger/judul.jpg');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Karakter Bebek</span>
						</div>
					</div>
				</a>

				<a href="Botol/botol_xintiger" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/botol/xintiger/judul.jpg');?>" >
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Botol Karakter Bebek</span>
						</div>
					</div>
				</a>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<!-- End Kategori Produk -->