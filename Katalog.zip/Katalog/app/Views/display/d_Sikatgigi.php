<!-- Kategori Produk -->
<section class="bg-Light"> 
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold">Produk Sikat Gigi</h1>
		</div>
		<!-- Body Kategori -->
		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">
				<a href="/Sikatgigi/singa" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/singa/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Singa</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/paw" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/paw/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Singa Paw</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/serigala" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/serigala/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Serigala</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/polulu_small" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/polulu_kecil/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Polulu Small</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/love" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/sglove/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi love</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/buaya" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/sgbuaya/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Buaya</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/cocomelon" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/cocomelon/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Cocomelon</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/kaki_dino" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/sgkakidino/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Cocomelon</span>
						</div>
					</div>
				</a>

				<a href="/Sikatgigi/jerapah" class="text-decoration-none">
					<div class="box hover"> 
						<img src="<?= base_url('assets/img/produk/sikat_gigi/sgjerapah/judul.jpg');?>" style="
						height: 180px;
					    width: 180px;
					    margin: auto;
					    border-radius: 10px;
					    margin-top: 10px;
					    margin-bottom: 10px;">
						<div class="box-image">
							
						</div>
						<div>
							<span class="text-secondary">Sikat Gigi Cocomelon</span>
						</div>
					</div>
				</a>
			</div>
		</div> 
	</div>
</section>

<!-- End Kategori Produk -->