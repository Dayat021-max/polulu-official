<style>
    .navbar {
        background: #3b51de;
        margin: 0;
        padding: 20px 30px;
        z-index: 99;
    }

    .logo {
        font-size: 14pt;
        font-weight: bold;
        text-decoration: none;
        color: white;
    }

    .logo:hover
    {
    	color: #99c3ff;
    }

    .tombol {
        display: none;
        color: white;
        font-size: 14pt;
    }

    .tombol:hover {
        cursor: pointer;
    }

    .menu {
        margin: 0;
        max-height: 200px;
        display: flex;
        list-style: none;
        padding: 0;
        transition: 0.5s;
    }

    .menu li {
        padding-left: 0;
        margin-right: 10px;
    }

    .menu li a {
        padding: 10px;
        color: white;
        text-decoration: none;
        display: inline-block;
    }

    @media screen and (max-width: 768px) {
    .menu {
        display: none;
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.5s ease-out; /* Adjust duration and timing function as needed */
    }

    .menu.aktif {
        display: inline-block;
        max-height: 300px; /* Atur nilai maksimum tinggi yang sesuai */
        position: absolute;
        top: 64px;
        background: #3b51de;
        padding: 10px 20px;
        right: 0;
        left: 0;
        transition: max-height 0.5s ease-in-out; /* Sama dengan yang sebelumnya */
    }

    .menu.aktif li a { 
        padding: 10px;
        display: inline-block !important;
    }

    .tombol {
        display: block;
    }
}

</style>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <a href="https://www.malasngoding.com" class="logo text-decoration-none">Polulu Official</a>
        
        <ul class="menu">
        	<hr style="color: white; margin: 0;" >
            <li><a href="#">Home</a></li>
            <hr style="color: white; margin:0;" >

            <li><a href="#">Tentang</a></li>
            <hr style="color: white; margin: 0;" >
            <li><a href="#">Produk</a></li>
            <hr style="color: white; margin: 0;" >
            <li><a href="#">Layanan</a></li>
            <hr style="color: white; margin: 0;" >
            <li><a href="#">Kontak Kami</a></li>
        </ul>
        
        <div class="tombol" >
            &#9776;
        </div>
    </div>
</nav>

<script>
    // deklarasi tombol dan menu
    const tombol = document.querySelector('.tombol');
    const menu = document.querySelector('.menu');

    // membuat event click
    // pada saat tombol di click, tambahkan class aktif pada class menu
    // saat diklik lagi, maka class aktif dihilangkan dari class menu (toggle)
    tombol.addEventListener('click', () => {
        menu.classList.toggle('aktif');
    });
</script>
