<main>
    <div class="container">
        <section class="section error-404 min-vh-100 d-flex flex-column align-items-center justify-content-center">
            <div class="d-flex justify-content-center py-4">
                <a href="index.html" class="logo d-flex align-items-center w-auto text-decoration-none">
                    <img src="<?= base_url('assets/') ?>img/out/icon.png" alt="">
                    <span class="d-none d-lg-block">Polulu Official - <?= $judul ?></span>
                </a>
            </div> 
            <div class="col-lg-12">
                <div class="row">
                    <div class="card bg-white" style="z-index : 1;">
                        <div class="card-body">
                            <form action="<?= base_url('Item/save') ?>" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                                <?= csrf_field(); ?>

                                <!-- Input Pertama -->
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="produk" class="form-label">Nama Produk</label>
                                            <input type="text" class="form-control" id="produk" name="produk" required>
                                            <div class="invalid-feedback">Nama Produk tidak boleh kosong.</div>
                                            <input type="hidden" class="form-control" id="inputPMT" name="user" value="<?= $nama['id'] ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="kategori" class="form-label">Kategori</label>
                                            <select class="form-select" id="kategori" required name="kategori">
                                                <option selected disabled value="">Pilih kategori</option>
                                                <?php foreach ($dat_kategori as $kat): ?>
                                                    <option value="<?= $kat['id'] ?>"><?= $kat['kategori'] ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <div class="invalid-feedback">Kategori tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="harga_eceran" class="form-label">Harga Eceran</label>
                                            <input type="text" class="form-control rupiah" id="harga_eceran_display" required>
                                            <input type="hidden" id="harga_eceran" name="harga_eceran">
                                            <div class="invalid-feedback">Harga Eceran tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="barcode" class="form-label">Nomor Faktur:</label>
                                            <input type="text" id="barcode" name="barcode" placeholder="Masukkan nomor faktur atau biarkan kosong" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="harga_grosir1" class="form-label">Harga Grosir 1</label>
                                            <input type="text" class="form-control rupiah" id="harga_grosir1_display" required>
                                            <input type="hidden" id="harga_grosir1" name="harga_grosir1">
                                            <div class="invalid-feedback">Harga Grosir 1 tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="harga_grosir2" class="form-label">Harga Grosir 2</label>
                                            <input type="text" class="form-control rupiah" id="harga_grosir2_display" required>
                                            <input type="hidden" id="harga_grosir2" name="harga_grosir2">
                                            <div class="invalid-feedback">Harga Grosir 2 tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="harga_grosir3" class="form-label">Harga Grosir 3</label>
                                            <input type="text" class="form-control rupiah" id="harga_grosir3_display" required>
                                            <input type="hidden" id="harga_grosir3" name="harga_grosir3">
                                            <div class="invalid-feedback">Harga Grosir 3 tidak boleh kosong.</div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Input Pertama End -->

                                <!-- Input Gambar -->
                                <div class="row justify-content-center">
                                    <div class="col-sm-4">
                                        <div class="card">
                                            <img src="<?= base_url('assets/img/item/default.png') ?>" id="preview_judul" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                            <div class="card-body">
                                                <input type="file" id="image_judul" class="image-input form-control" accept="image/*" name="judul" required>
                                                <div class="invalid-feedback">Gambar 1 tidak boleh kosong.</div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- <div class="col-xl-12">
                                    <div class="d-flex flex-wrap justify-content-center"> -->
                                        <div class="col-sm-4">
                                              <div class="card">
                                                <img src="<?= base_url('assets/img/item/default.png') ?>" id="preview_1" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_1" class="image-input form-control" accept="image/*" name="judul">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_2" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_2" class="image-input form-control" accept="image/*" name="foto1">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_3" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_3" class="image-input form-control" accept="image/*" name="foto2">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_4" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_4" class="image-input form-control" accept="image/*" name="foto3">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_5" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_5" class="image-input form-control" accept="image/*" name="foto4">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_6" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_6" class="image-input form-control" accept="image/*" name="foto5">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_7" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_7" class="image-input form-control" accept="image/*" name="foto6">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_8" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_8" class="image-input form-control" accept="image/*" name="foto7">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_9" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_9" class="image-input form-control" accept="image/*" name="foto8">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-sm-4">
                                            <div class="card">
                                                <img src="<?= base_url('assets/img/default.png') ?>" id="preview_10" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                                                <div class="card-body">
                                                    <input type="file" id="image_10" class="image-input form-control" accept="image/*" name="foto9">
                                                </div>
                                            </div>
                                        </div>
                                    <!-- </div>
                                </div> -->

                                    <!-- Tambahkan elemen input gambar lainnya di sini -->

                                </div>
                                <!-- End Input Gambar -->

                                <!-- Input Spesifikasi & Deskripsi -->
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="p_model" class="form-label">Produk Model</label>
                                            <input type="text" class="form-control" id="p_model" name="p_model" required>
                                            <div class="invalid-feedback">Produk Model tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="p_size" class="form-label">Produk Size</label>
                                            <input type="text" class="form-control" id="p_size" name="p_size" required>
                                            <div class="invalid-feedback">Produk Size tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="p_material" class="form-label">Produk Material</label>
                                            <input type="text" class="form-control" id="p_material" name="p_material" required>
                                            <div class="invalid-feedback">Produk Material tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="p_kapasitas" class="form-label">Produk Kapasitas</label>
                                            <input type="text" class="form-control" id="p_kapasitas" name="p_kapasitas" required>
                                            <div class="invalid-feedback">Produk Kapasitas tidak boleh kosong.</div>
                                        </div>

                                        <div class="form-group">
                                            <label for="p_warna" class="form-label">Produk Warna</label>
                                            <input type="text" class="form-control" id="p_warna" name="p_warna" required>
                                            <div class="invalid-feedback">Produk Warna tidak boleh kosong.</div>
                                        </div>
                                    </div>

                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="keterangan" class="form-label">Deskripsi Barang</label>
                                            <textarea class="form-control" placeholder="keterangan" id="keterangan" style="height: 100px;" name="keterangan" required></textarea>
                                            <div class="invalid-feedback">Deskripsi Barang tidak boleh kosong.</div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Input Spesifikasi & Deskripsi -->

                                <div class="row justify-content-center text-center mt-3">
                                    <div class="col-sm-6" style="z-index: 1;">
                                        <a class="btn btn-success" href="<?= base_url('Item'); ?>">Kembali</a>
                                    </div>
                                    <div class="col-sm-6" style="z-index: 1;">
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
            <img src="<?= base_url('assets/') ?>img/not-found.svg" class="img-fluid py-5" alt="Page Not Found" style="position: fixed; bottom: 0px;">
        </section>
    </div>

    <script type="text/javascript">
    document.querySelectorAll('.image-input').forEach(input => {
    input.addEventListener('change', function(event) {
        const file = event.target.files[0];
        const previewId = 'preview_' + input.id.split('_')[1];
        const previewImg = document.getElementById(previewId);

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
            }
            reader.readAsDataURL(file);
        } else { 
            previewImg.src = 'assets/img/default.png'; // Placeholder image URL if no file is selected
        }
    });
}); 

</script>

<!-- Rupiah -->
<script>
    document.querySelectorAll('.rupiah').forEach(function(input) {
        input.addEventListener('keyup', function(e) {
            var value = this.value.replace(/[^,\d]/g, '').toString();
            var split = value.split(',');
            var sisa = split[0].length % 3;
            var rupiah = split[0].substr(0, sisa);
            var ribuan = split[0].substr(sisa).match(/\d{3}/gi);

            if (ribuan) {
                var separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
            }

            rupiah = split[1] !== undefined ? rupiah + ',' + split[1] : rupiah;
            this.value = 'Rp ' + rupiah;

            // Update hidden input yang sesuai
            var hiddenInputId = this.id.replace('_display', '');
            document.getElementById(hiddenInputId).value = value.replace(/\./g, '').replace(',', '.');
        });
    });
</script>

<!-- Rupiah -->
</main>
