<!-- Kategori Produk -->  
<section class="bg-Light p-5">
		<?php foreach($Item as $i ) : ?> 
			<!-- Head Kategori --> 
			<!-- <div class="text-center pt-5 pb-3">
				<h1 class="text-secondary font-weight-bold display-4"><?= $i['produk'] ?></h1>
			</div> -->
		<!-- Body Kategori -->
		<div class="container text-center"> 
			
			<div class="row"> 
				<div class="col-lg-6"> 
					<div class="col-12">
							<div class="image-container"> 
								<input type="hidden" name="id" class="form-control" value="<?= $i['id'] ?>">
								<img id="mainImage" src="<?= base_url('assets/img/item/'.$i['judul']);?>" alt="Main Image" onmousemove="zoom(event)">
					        	<!-- <img id="mainImage" src="<?= base_url('assets/img/produk/mangkuk/turku3/judul.png');?>" alt="Main Image" onmousemove="zoom(event)"> -->
					    	</div>
					    <div class="thumbnail-container">

					        <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['judul']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['judul']);?>')" class="box_detail">
					        <?php if (!empty($i['foto1']) && $i['foto1'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto1']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto1']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto2']) && $i['foto2'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto2']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto2']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto3']) && $i['foto3'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto3']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto3']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto4']) && $i['foto4'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto4']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto4']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto5']) && $i['foto5'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto5']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto5']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto6']) && $i['foto6'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto6']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto6']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto7']) && $i['foto7'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto7']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto7']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto8']) && $i['foto8'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto8']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto8']);?>')" class="box_detail">
							<?php endif; ?>

							<?php if (!empty($i['foto9']) && $i['foto9'] != 'default.png'): ?>
							    <img class="thumbnail-item" src="<?= base_url('assets/img/item/'.$i['foto9']);?>" alt="Thumbnail 1" onclick="changeImage('<?= base_url('assets/img/item/'.$i['foto9']);?>')" class="box_detail">
							<?php endif; ?>
					    </div>
					</div>

					<?php
					// Fungsi untuk format Rupiah
					function rupiah($angka){
					    return "Rp " . number_format($angka, 0, ',', '.');
					}
					?>

					<div class="col-12">
						<div class="contact">
							<div class="title_header mt-3">
								<label class="mt-3 mb-0 font-weight-bold" >Harga Ecer</label>
								<div class="mb-4">
									<label class="m-0 display-5 rupiah"><?= rupiah($i['harga_eceran']) ?></label> 
								</div>
								<label class="mt-3 mb-0 font-weight-bold" >Harga Grosir</label>
								<div class="d-flex justify-content-center">
									<label class="m-2"><?= rupiah($i['harga_grosir1']) ?></label>
									<label class="m-2"><?= rupiah($i['harga_grosir2']) ?></label>
									<label class="m-2"><?= rupiah($i['harga_grosir3']) ?></label>
								</div>
								<h4>bisa dinego langsung</h4>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="title_header">
						<h1 class="mb-4 font-weight-bold"><label> <?= $i['produk'] ?> </label></h1>
						<h1 class="mb-4"><label> Spesifikasi Produk</label></h1>
					</div>
					<div class="deskripsi">
						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Model</label>
							 </div>
							 <div class="col text-left">
							 	<label><?= $i['produk_model'] ?></label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Size</label>
							 </div>
							 <div class="col text-left">
							 	<label><?= $i['produk_size'] ?></label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Material</label>
							 </div>
							 <div class="col text-left">
							 	<label><?= $i['produk_material'] ?></label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Kapasitas</label>
							 </div>
							 <div class="col text-left">
							 	<label>produk kapasitas</label>
							 </div>
						</div>

						<div class="row justify-content-center pl-3 pr-3">
							 <div class="col text-left">
							 	<label class="font-weight-bold">Produk Warna</label>
							 </div>
							 <div class="col text-left">
							 	<label><?= $i['produk_warna'] ?></label>
							 </div>
						</div>
					</div>
					<div class="title_header">
						<h1 class="mb-4"><label>Deskripsi</label></h1>
						<div class="deskripsi">
							<p class="text-justify"><?= $i['keterangan'] ?></p>
						</div>
						<div class="title_body mt-5">
						<h1>Segera hubungi :</h1>
						<div class="d-flex mt-3 ">
							<div class="row justify-content-center pl-5 pr-5">
								<a href=""  id="WAmita" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Mita</h3>
									 </div>
								 </a>

								 <a href="" id="WAayu" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ayu</h3>
									 </div>
								 </a>
							</div>
 
							<div class="row justify-content-center pl-5 pr-5">
								<a href="" id="WAersa" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Ersa</h3>
									 </div>
								 </a>

								 <a href="" id="WAecha" style="text-decoration: none;" class="text-secondary">
									 <div class="col text-left">
									 <h3> <i class="bi bi-whatsapp"></i> Cs Echa</h3>
									 </div>
								 </a>
							</div>
						</div>
					</div>
				</div>
			</div>			  
		<?php endforeach; ?>
		</div>

	</div>
</section>
<script>
	function myFunction(imgs) {
	  // Get the expanded image
	  var expandImg = document.getElementById("expandedImg");
	  // Get the image text
	  var imgText = document.getElementById("imgtext");
	  // Use the same src in the expanded image as the image being clicked on from the grid
	  expandImg.src = imgs.src;
	  // Use the value of the alt attribute of the clickable image as text inside the expanded image
	  imgText.innerHTML = imgs.alt;
	  // Show the container element (hidden with CSS)
	  expandImg.parentElement.style.display = "block";
}
</script>

<!-- image preview dkk -->
<script>
        const container = document.getElementById('thumbnailContainer');

        let isDown = false;
        let startX;
        let scrollLeft;

        container.addEventListener('mousedown', (e) => {
            isDown = true;
            container.classList.add('active');
            startX = e.pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
            container.style.cursor = 'grabbing';
        });

        container.addEventListener('mouseleave', () => {
            isDown = false;
            container.classList.remove('active'); 
            container.style.cursor = 'grab';
        });

        container.addEventListener('mouseup', () => {
            isDown = false;
            container.classList.remove('active');
            container.style.cursor = 'grab';
        });

        container.addEventListener('mousemove', (e) => {
            if (!isDown) return;
            e.preventDefault();
            const x = e.pageX - container.offsetLeft;
            const walk = (x - startX) * 3; // Jumlah scroll (lebih besar untuk scrolling lebih cepat)
            container.scrollLeft = scrollLeft - walk;
        });

        // Untuk perangkat mobile
        container.addEventListener('touchstart', (e) => {
            isDown = true;
            startX = e.touches[0].pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
        });

        container.addEventListener('touchend', () => {
            isDown = false;
        });

        container.addEventListener('touchmove', (e) => {
            if (!isDown) return;
            const x = e.touches[0].pageX - container.offsetLeft;
            const walk = (x - startX) * 3; // Jumlah scroll (lebih besar untuk scrolling lebih cepat)
            container.scrollLeft = scrollLeft - walk;
        });
</script>
<!-- end image preview dkk -->

<script> 
    function zoom(e) {
        var zoomer = e.currentTarget;
        var offsetX = e.offsetX ? e.offsetX : e.touches[0].pageX;
        var offsetY = e.offsetY ? e.offsetY : e.touches[0].pageY;
        var x = (offsetX / zoomer.offsetWidth) * 100;
        var y = (offsetY / zoomer.offsetHeight) * 100;
        zoomer.style.transformOrigin = x + '% ' + y + '%';
        zoomer.style.transform = 'scale(2)';
    }

    function changeImage(src) {
        var mainImage = document.getElementById('mainImage');
        mainImage.src = src;
        mainImage.style.transform = 'scale(1)'; // Reset zoom on image change
    }

    document.getElementById('mainImage').addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
    });
</script>
<!-- end zoom gallery -->


<!-- End Kategori Produk --> 