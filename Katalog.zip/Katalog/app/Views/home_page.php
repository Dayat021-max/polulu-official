<!-- Hero -->
<section class="bg-secondary"> 
<div class="owl-carousel owl-theme">
    <div class="item"

    style="
    background-image: url('assets/img/hero/b2.webp');
    border-radius: 20px;
    background-size: cover;
    ">
    	
    </div>
    <div class="item"

    style="
    background-image: url('assets/img/hero/b1.webp');
    border-radius: 20px;
    background-size: cover;
    ">
    </div>
</div>
</section>
<!-- End Hero --> 
 
<!-- Kategori Database -->
<section> 
	<div class="bg-light">
		<div class="container text-center">
			<div class="text-center pt-5 pb-5">
				<h1 class="text-secondary font-weight-bold"><?= $sub; ?></h1>
			</div>
			<!-- body kategori database -->
			<div class="container mb-5">
				<div class="d-flex flex-wrap justify-content-center">
					<?php foreach ($kategori as $kat) : ?>
					<a href="/Landpage/list/<?= $kat['id']; ?>" class="text-decoration-none">  <!-- perlu pindah file -->
						<div class="box hover">
							<img src="<?= base_url('assets/img/kategori/'. $kat['img']) ?>" >
							<div class="box-image">
								
							</div>
							<div>
								<span class="text-secondary" ><?= $kat['kategori'] ?></span>
							</div>
						</div>
					</a>
				<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- end kategori database -->

<!-- Kategori Produk -->



<!-- End Kategori Produk -->

<!-- Produk Populer -->

<section class="bg-Light">
	<div class="container text-center">
		<!-- Head Kategori -->
		<div class="text-center pt-5 pb-5">
			<h1 class="text-secondary font-weight-bold">Produk Populer </h1>
		</div>

		<div class="container mb-5	">
			<div class="col-lg-12 d-flex flex-wrap justify-content-center">
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>

				<!-- coba flex -->
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<div class="box hover">
					<img src="assets/img/hero/b1.webp">
					<div class="box-image">
						
					</div>
					<div>
						<span class="text-secondary">sikat Gigi</span>
					</div>
				</div>
				<!--  -->
			</div>
		</div>
	</div>
</section>

<section  class="h_footer">
	<div class="container">
		<div class="d-flex justify-content-around">
			<div class="col-lg-3 p-5 text-white">
				<div>
					<h3>Contact Us</h3>
				</div>
				<div  class="list">
					<ul style="list-style: none;">
						<li>
							<i class="bi bi-whatsapp"></i>
							<!-- <button id="WAmita">CS Mita</button> -->
							<a href="" id="WAmita" style="text-decoration: none; color:white;">Cs Mita</a>
						</li>
						<li>
							<i class="bi bi-whatsapp"></i>
							<!-- <button id="WAayu">CS Ayu</button> -->
							<a href="" id="WAayu" style="text-decoration: none; color:white;">Cs Ayu</a>
						</li>
						<li>
							<i class="bi bi-whatsapp"></i>
							<!-- <button id="WAersa">CS Ersa</button> -->
							<a href="" id="WAersa" style="text-decoration: none; color:white;">Cs Ersa</a>
						</li>
						<li>
							<i class="bi bi-whatsapp"></i>
							<!-- <button id="WAecha">CS Echa</button> -->
							<a href="" id="WAecha" style="text-decoration: none; color:white;">Cs Echa</a>
						</li>
					</ul>
				</div>

				
			</div>
			<!-- <div class="col-lg-3 p-5">
				<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua.</p>
			</div> -->
			<div class="col-lg-3">
				<img src="<?= base_url('assets/img/hero/polulu-maskot.png');?>" style="width: 150px;">
			</div> 
		</div>
	</div>
</section>

<script>
/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

<!-- <script>
  window.addEventListener('scroll', function() {
  const topbar = document.getElementById('topbar');
  if (window.scrollY > 50) { 
    topbar.classList.add('scrolled');
  } else {
    topbar.classList.remove('scrolled');
  }
}); 
 
</script> -->

<script>
    // deklarasi tombol dan menu
    const tombol = document.querySelector('.tombol');
    const menu = document.querySelector('.menu');

    // membuat event click
    // pada saat tombol di click, tambahkan class aktif pada class menu
    // saat diklik lagi, maka class aktif dihilangkan dari class menu (toggle)
    tombol.addEventListener('click', () => {
        menu.classList.toggle('aktif');
    });
</script>

<script>
    $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            items: 1,
            loop: true,
            margin: false,
            nav: false,
            dots: false,
            autoplay: true,
            autoplayTimeout: 5000,
            autoplayHoverPause: true
        });
    });
</script>
<script src="<?php echo base_url('assets/js/link.js');?>"></script>

<!-- End Produk Terbaik -->