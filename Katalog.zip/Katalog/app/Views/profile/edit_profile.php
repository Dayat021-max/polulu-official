<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $judul; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('/Dashboard'); ?>">Home</a></li>
          <li class="breadcrumb-item active">Kategori</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row justify-content-center">
        <!-- Left side columns -->  
        <div class="col-lg-8"> 
          <div class="row">
            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title text-center">
                    Tambah Data User <span>| Today</span>
                  </h5> 
 
                  <!-- Table -->   
                  <div class="mt-3">

                    <?php foreach ($us as $user): ?>
                      <form action="<?= base_url('Registrasi/update/'.$user['id']) ?>" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
                        <?= csrf_field(); ?>
                        <!-- <input type="hidden" name="oldProfilePicture" value="<?= $user['id']; ?>">
                        <input type="hidden" name="oldPassword" value="<?= $user['password']; ?>"> -->
                        <div class="form-group">
                          <label for="nama">Nama</label>
                          <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama']; ?>" required>
                          <div class="invalid-feedback">Nama tidak boleh kosong.</div>
                        </div>
                        <div class="form-group">
                          <label for="username">Username</label>
                          <input type="text" class="form-control" id="username" name="username" value="<?= $user['username']; ?>" required>
                          <div class="invalid-feedback">Username tidak boleh kosong.</div>
                        </div>
                        <div class="form-group">
                          <label for="role_id" class="form-label">Job Position</label>
                          <select class="form-select" id="role_id" required name="role_id">
                            <option value="" disabled selected>Pilih Role</option>
                            <?php foreach ($rol_id as $rol): ?>
                              <option value="<?= $rol['id'] ?>" <?= ($user['role_id'] == $rol['id']) ? 'selected' : '' ?>>
                                <?= $rol['role_id'] ?>
                              </option>
                            <?php endforeach; ?>
                          </select>
                          <div class="invalid-feedback">Kategori tidak boleh kosong.</div>
                        </div>
                        <div class="form-group">
                          <label for="status" class="form-label">Status</label>
                          <select class="form-select" id="status" required name="status">
                            <option value="" disabled selected>Pilih Status</option>
                            <?php foreach ($dat_status as $stat): ?>
                              <option value="<?= $stat['id'] ?>" <?= ($user['id_status'] == $stat['id']) ? 'selected' : '' ?>>
                                <?= $stat['kondisi'] ?>
                              </option>
                            <?php endforeach; ?>
                          </select>
                          <div class="invalid-feedback">Status tidak boleh kosong.</div>
                        </div>
                        <br>
                        <!-- Image -->
                        <div class="form-group">
                          <div class="card">
                            <img src="<?= base_url('assets/img/user/'. $user['image']) ?>" id="preview_9" class="card-img-top" alt="Image preview" style="max-width: 100%;">
                            <div class="card-body">
                              <input type="file" id="image_9" class="image-input form-control" accept="image/*" name="pp">
                            </div>
                          </div>
                        </div>
                        <!-- Image -->
                        <button type="submit" class="btn btn-primary">Update</button>
                      </form>
                    <?php endforeach; ?>

                  </div> 
                </div> 
              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->
      </div>
    </section>
        <script type="text/javascript"> 
    document.querySelectorAll('.image-input').forEach(input => {
    input.addEventListener('change', function(event) {
        const file = event.target.files[0];
        const previewId = 'preview_' + input.id.split('_')[1];
        const previewImg = document.getElementById(previewId);

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
            }
            reader.readAsDataURL(file);
        } else { 
            previewImg.src = 'assets/img/default.png'; // Placeholder image URL if no file is selected
        }
    });
}); 

</script>
</main><!-- End #main -->
