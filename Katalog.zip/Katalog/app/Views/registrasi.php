    <main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $judul; ?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('/Dashboard'); ?>">Home</a></li>
          <li class="breadcrumb-item active">Kategori</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row justify-content-center">
        <!-- Left side columns -->
        <div class="col-lg-10"> 
          <div class="row">
            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">
                <div class="card-body">
                  <h5 class="card-title text-center ">Tambah Data User<span>| Today</span>
                  </h5>
                  <div class="d-flex align-items-center justify-content-end">
                    <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#staticBackdrop">Tambah Data</button>
                  </div>

                  <!-- Table --> 
                  <div class="mt-3"> 
                    <table id="myTable" class="display text-center table">
                        <thead class="thead-light"> 
                            <tr>  
                                <th class="text-center" >No</th>
                                <th class="text-center">Nama User</th>
                                <th class="text-center">Job Position</th>
                                <th class="text-center">Tanggal Input</th>
                                <th class="text-center">Foto</th> 
                                <th class="text-center">Tools</th> 
                            </tr>
                        </thead>
                        <tbody> 
                          <?php $no = 1; ?>
                          <?php foreach( $user_account as $user ): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $user['nama'] ?></td>
                                <td> 
                                <?= $user['role_name'] ?>     
                                </td>
                                <td><?= $user['created_at'] ?></td> 
                                <td>
                                  <img src="<?= base_url('assets/img/user/'.$user['image']) ?>" class="rounded zoom" width="100" >
                                  <!-- <img src="assets/img/<?= $user['image'] ?>" alt="Profile Picture" width="100"  class="rounded zoom"> -->
                                </td>                               
                                <td class="text-center">  
                                <form action="<?= base_url('Registrasi/reset_password/'.$user['id']) ?>" method="post">
                                <?= csrf_field(); ?>  
                                  <a class="btn btn-warning" name="password" value="Polulu_Official" >Reset Password</a>
                                
                                  <a href="/Registrasi/edit/<?= $user['id'] ?>" class="btn btn-primary">Edit</a>
                                </form>
                                </td>
                            </tr>
                          <?php endforeach;  ?>
                        </tbody>
                    </table>
                  <!-- End Table -->
                  </div>

                </div> 
              </div>
            </div><!-- End Recent Sales -->
          </div>
        </div><!-- End Left side columns -->
      
      </div>
    </section>
 
<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Tambah Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- Start Form -->
        <form action="Registrasi/save" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
          <?= csrf_field(); ?>
          <!-- Nama User -->
          <div class="form-group">
            <label for="name" class="form-label">Nama User</label>
            <input type="text" name="name" class="form-control" id="name" required autofocus>
            <div class="invalid-feedback">Nama tidak boleh kosong.</div>
          </div>
          <!-- End Nama User -->

          <!-- User name Login -->
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" class="form-control" id="username" required>
            <div class="invalid-feedback">Username tidak boleh kosong.</div>
          </div>
          <!-- End User name Login -->

          <!-- Nomor Handphone -->
          <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" class="form-control" id="username" required>
            <div class="invalid-feedback">Username tidak boleh kosong.</div>
          </div>
          <!-- End Nomor Handphone -->

          <!-- User Role -->
          <div class="form-group">
            <label for="role" class="form-label">Posisi Pekerjaan</label>
            <select class="form-select" id="role" required name="role_id">
              <option selected disabled value="">Pilih kategori</option>
              <?php foreach ($rol_id as $rol): ?>
                <option value="<?= $rol['id'] ?>"><?= $rol['role_id'] ?></option>
              <?php endforeach; ?>
            </select>
            <div class="invalid-feedback">Posisi Pekerjaan tidak boleh kosong.</div>
          </div>
          <!-- End User Role -->

          <!-- Image -->
          <div class="form-group">
            <div class="card">
              <img src="<?= base_url('assets/img/default.png') ?>" id="preview_1" class="card-img-top" alt="Image preview" style="max-width: 100%;">
              <div class="card-body">
                <input type="file" id="image_1" class="image-input form-control" accept="image/*" name="pp">
              </div>
            </div>
          </div>
          <!-- End Image -->

          <!-- Password -->
          <div class="form-group" id="secret">
            <input type="hidden" class="form-control" id="password" value="Polulu_Official" name="password">
          </div>
          <!-- End Password -->

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
        </form>
        <!-- End Form -->
      </div>
    </div>
  </div>
</div>

   <script type="text/javascript">
    document.querySelectorAll('.image-input').forEach(input => {
    input.addEventListener('change', function(event) {
        const file = event.target.files[0];
        const previewId = 'preview_' + input.id.split('_')[1];
        const previewImg = document.getElementById(previewId);

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                previewImg.src = e.target.result;
            }
            reader.readAsDataURL(file);
        } else { 
            previewImg.src = 'assets/img/default.png'; // Placeholder image URL if no file is selected
        }
    });
}); 

</script>


  </main><!-- End #main -->