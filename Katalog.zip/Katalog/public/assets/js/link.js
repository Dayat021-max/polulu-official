document.getElementById('WAmita').addEventListener('click', function() {
    const phoneNumber = '6285219221225'; // Ganti dengan nomor WhatsApp tujuan
    const message = 'Halo, saya ingin memesan beberapa produk';
    const encodedMessage = encodeURIComponent(message);

    const waLink = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(waLink, '_blank');
});

document.getElementById('WAayu').addEventListener('click', function() {
    const phoneNumber = '6285280105531'; // Ganti dengan nomor WhatsApp tujuan
    const message = 'Halo, saya ingin memesan beberapa produk';
    const encodedMessage = encodeURIComponent(message);

    const waLink = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(waLink, '_blank');
});

document.getElementById('WAersa').addEventListener('click', function() {
    const phoneNumber = '6285219943778'; // Ganti dengan nomor WhatsApp tujuan
    const message = 'Halo, saya ingin memesan beberapa produk';
    const encodedMessage = encodeURIComponent(message);

    const waLink = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(waLink, '_blank');
});

document.getElementById('WAecha').addEventListener('click', function() {
    const phoneNumber = '6285219220972'; // Ganti dengan nomor WhatsApp tujuan
    const message = 'Halo, saya ingin memesan beberapa produk';
    const encodedMessage = encodeURIComponent(message);

    const waLink = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(waLink, '_blank');
});
